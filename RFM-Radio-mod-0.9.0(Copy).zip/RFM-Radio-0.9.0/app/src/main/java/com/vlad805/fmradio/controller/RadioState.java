package com.vlad805.fmradio.controller;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * A class that stores the current state of the radio tuner, audio service and other
 * parameters.
 * The main storage is located in the FMService, but on demand it can be transferred
 * to an Activity, Fragment or other Service using Parcelable.
 * Changing an instance of this class can only be done using the class RadioStateUpdater.
 * vlad805 (c) 2021
 */
public final class RadioState implements Parcelable {
    public static final int RMSSI_UNKNOWN = Integer.MIN_VALUE;

    // State of tuner
    private TunerStatus status = TunerStatus.IDLE;

    // Frequency in kHz
    private int frequency = 0;

    // PI - Program ID (hex)
    private String pi;

    // ISO 3166-1 alpha-2 country code decoded from RDS ECC and PI
    private String country = "";

    // PTY - Program TYpe
    private int pty;

    // PS - Program Service
    private String ps = "";

    // RT - Radio Text
    private String rt = "";

    // Stereo - is stereo audio?
    private boolean stereo;

    // Signed receiver signal strength reported by the tuner.
    private int rmssi = RMSSI_UNKNOWN;

    // Is recording started
    private boolean recording = false;

    // Effective recording start timestamp, shifted back by included pre-roll
    private long recordingStarted = -1L;

    // Outputting sound from speakers
    private boolean forceSpeaker = false;

    public RadioState() {

    }

    public TunerStatus getStatus() {
        return status;
    }

    void setStatus(final TunerStatus status) {
        this.status = status;
    }

    public int getFrequency() {
        return frequency;
    }

    void setFrequency(final int frequency) {
        this.frequency = frequency;
    }

    public String getPi() {
        return pi;
    }

    void setPi(final String pi) {
        this.pi = pi;
    }

    public String getCountry() {
        return country;
    }

    void setCountry(final String country) {
        this.country = country;
    }

    public int getPty() {
        return pty;
    }

    void setPty(final int pty) {
        this.pty = pty;
    }

    public String getPs() {
        return ps;
    }

    void setPs(final String ps) {
        this.ps = ps;
    }

    public String getRt() {
        return rt;
    }

    void setRt(final String rt) {
        this.rt = rt;
    }

    public boolean isStereo() {
        return stereo;
    }

    void setStereo(final boolean stereo) {
        this.stereo = stereo;
    }

    public int getRmssi() {
        return rmssi;
    }

    void setRmssi(final int rmssi) {
        this.rmssi = rmssi;
    }

    public boolean isRecording() {
        return recording;
    }

    void setRecording(final boolean recording) {
        this.recording = recording;
    }

    public long getRecordingDuration() {
        return recording ? (System.currentTimeMillis() - recordingStarted) / 1000 : -1L;
    }

    public long getRecordingStarted() {
        return recordingStarted;
    }

    /**
     * Sets the effective recording start, including any pre-roll duration.
     *
     * @param recordingStarted Start timestamp in milliseconds
     */
    void setRecordingStarted(final long recordingStarted) {
        this.recordingStarted = recordingStarted;
    }

    public boolean isForceSpeaker() {
        return forceSpeaker;
    }

    void setForceSpeaker(boolean forceSpeaker) {
        this.forceSpeaker = forceSpeaker;
    }

    protected RadioState(final Parcel in) {
        status = (TunerStatus) in.readValue(TunerStatus.class.getClassLoader());
        frequency = in.readInt();
        pi = in.readString();
        country = in.readString();
        pty = in.readInt();
        ps = in.readString();
        rt = in.readString();
        stereo = in.readInt() > 0;
        rmssi = in.readInt();
        recording = in.readInt() > 0;
        recordingStarted = in.readLong();
        forceSpeaker = in.readInt() > 0;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(final Parcel dest, int flags) {
        dest.writeValue(status);
        dest.writeInt(frequency);
        dest.writeString(pi);
        dest.writeString(country);
        dest.writeInt(pty);
        dest.writeString(ps);
        dest.writeString(rt);
        dest.writeInt(stereo ? 1 : 0);
        dest.writeInt(rmssi);
        dest.writeInt(recording ? 1 : 0);
        dest.writeLong(recordingStarted);
        dest.writeInt(forceSpeaker ? 1 : 0);
    }

    public static final Parcelable.Creator<RadioState> CREATOR = new Parcelable.Creator<RadioState>() {
        @Override
        public RadioState createFromParcel(Parcel in) {
            return new RadioState(in);
        }

        @Override
        public RadioState[] newArray(int size) {
            return new RadioState[size];
        }
    };

    @Override
    public String toString() {
        return "TunerState{" +
                status +
                ", kHz=" + frequency +
                ", pi=" + pi +
                ", pty=" + pty +
                // ", ps='" + ps + '\'' +
                // ", rt='" + rt + '\'' +
                ", rec_st=" + recording +
                ", rec_be=" + recordingStarted +
                '}';
    }
}
