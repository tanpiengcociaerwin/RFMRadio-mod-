package com.vlad805.fmradio.service.fm;

/**
 * The interface for the controller, which constantly polls FM for updates,
 * for example, for PS, RT, etc..
 * vlad805 (c) 2020
 */
public interface IFMEventPoller {
	interface Callback<T> {
		void onResult(T result);
	}

	/**
	 * Call a poll for fresh data
	 * @param callback Call back with Bundle fresh data
	 * Supported values:
	 * 	- C.Key.FREQUENCY
	 *  - C.Key.PS
	 *  - C.Key.RT
	 */
	void poll(final Callback<android.os.Bundle> callback);
}
