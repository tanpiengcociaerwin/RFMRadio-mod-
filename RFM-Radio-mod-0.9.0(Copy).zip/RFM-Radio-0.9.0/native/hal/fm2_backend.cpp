#include "fm2_backend.h"

#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <string>

#include "../ctl_server.h"
#include "../frequency_format.h"
#include "../fm_v4l2_controls.h"
#include "../monotonic_clock.h"
#include "../region_profile.h"
#include "../rds_parser.h"
#include "../scan_result.h"
#include "../rmssi.h"
#include "fm2_vendor_iface.h"
#include "utils.h"

namespace {

constexpr const char *kFmLibraryName = "fm_helium.so";
constexpr const char *kFmLibrarySymbol = "FM_HELIUM_LIB_INTERFACE";

constexpr int kFmRxState = 1;

constexpr int kSearchModeSeek = 0;
constexpr int kSearchModeScan = 1;
constexpr int kSearchModeStrongList = 2;

constexpr int kHeliumSpacing200Khz = 0;
constexpr int kHeliumSpacing100Khz = 1;
constexpr int kHeliumSpacing50Khz = 2;

constexpr int kDefaultListSize = 20;
constexpr int kEnableWaitTimeoutMs = 2000;
constexpr uint64_t kRmssiRequestTimeoutMs = 5000;

// Qualcomm's stock WEAK threshold. Device scans found no useful benefit from
// stricter values, while the previous value (0x40) matched no known ABI scale.
constexpr int kDefaultSignalThreshold = -100;
// sweeping across the entire frequency range, it stops at each station found and pauses for N seconds
constexpr int kDefaultSeekDwell = 2;

struct RtpTag {
    int content_type = 0;
    int start = 0;
    int length = 0;
};

struct AudioState {
    bool stereo = true;
    bool mode_valid = false;
    bool mode_stereo = true;
    bool soft_mute = true;
    bool slimbus_enabled = false;
};

struct ScanState {
    bool active = false;
    bool wrapped = false;
    int start_frequency_khz = 0;
    int last_frequency_khz = 0;
    ScanResultCollector stations;
};

struct RmssiState {
    bool pending = false;
    uint64_t requested_at_ms = 0;
    int request_frequency_khz = 0;
    bool timeout_logged = false;
    bool paused = false;

    void clear_request() {
        pending = false;
        requested_at_ms = 0;
        request_frequency_khz = 0;
        timeout_logged = false;
    }
};

struct RuntimeState {
    void *lib_handle = nullptr;
    fm_interface_t *vendor = nullptr;
    bool initialized = false;
    bool enabled = false;
    AudioState audio;
    bool low_power = false;
    bool auto_af = false;
    int antenna = 0;
    StartupRegion region = StartupRegion::kEurope;
    int vendor_region = 0;
    int lower_band_khz = 87500;
    int upper_band_khz = 108000;
    int spacing_khz = 100;
    int vendor_spacing = 1;
    int emphasis = kFmEmphasis50Microseconds;
    int rds_standard = kFmRdsStandardRds;
    int current_frequency_khz = 87500;
    uint64_t last_enabled_cb_ms = 0;
    uint64_t last_tune_cb_ms = 0;
    uint64_t last_seek_cb_ms = 0;
    RmssiState rmssi;
    bool last_search_payload_valid = false;
    char last_search_payload[5 * 20 + 1] = "";
    ScanState scan;
    bool last_rt_plus_valid = false;
    unsigned char last_rt_plus[15] = {};
    bool last_ecc_valid = false;
    unsigned char last_ecc[12] = {};
    char current_rt[65] = "";
    int current_rt_len = 0;
    bool rt_plus_tags_valid = false;
    RtpTag rt_plus_tags[2];
    char last_error[128] = "";
    pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
} g_state;

void set_error_locked(const char *message) {
    const char *safe_message = message ? message : "unknown error";
    hal_log("error", "%s", safe_message);
    snprintf(g_state.last_error, sizeof(g_state.last_error), "%s", safe_message);
}

void clear_error_locked() {
    g_state.last_error[0] = '\0';
}

void reset_search_result_locked() {
    g_state.last_search_payload_valid = false;
    g_state.last_search_payload[0] = '\0';
}

void reset_scan_locked() {
    g_state.scan.active = false;
    g_state.scan.wrapped = false;
    g_state.scan.start_frequency_khz = 0;
    g_state.scan.last_frequency_khz = 0;
    g_state.scan.stations.reset();
}

void reset_rds_dedup_locked() {
    g_state.last_rt_plus_valid = false;
    g_state.last_ecc_valid = false;
    g_state.current_rt[0] = '\0';
    g_state.current_rt_len = 0;
    g_state.rt_plus_tags_valid = false;
}

bool is_duplicate_payload_locked(bool *valid, unsigned char *last, size_t last_size, const char *payload, int len) {
    if (len <= 0 || static_cast<size_t>(len) > last_size) {
        *valid = false;
        return false;
    }

    const bool duplicate = *valid && memcmp(last, payload, static_cast<size_t>(len)) == 0;
    if (!duplicate) {
        memcpy(last, payload, static_cast<size_t>(len));
        *valid = true;
    }
    return duplicate;
}

void log_length_prefixed_payload(const char *scope, const char *name, const char *payload, int extra_len = 0) {
    if (payload == nullptr) {
        hal_log(scope, "%s got null", name);
        return;
    }

    const int len = static_cast<unsigned char>(payload[0]) + extra_len;
    char dump[3 * 32 + 1];
    format_hex_dump(payload, len, dump, sizeof(dump));
    hal_log(scope, "%s len=%d data=%s%s", name, len, dump, len > 32 ? " ..." : "");
}

const char *rtp_content_type_name(int content_type) {
    switch (content_type) {
        case 1:
            return "ITEM.TITLE";
        case 4:
            return "ITEM.ARTIST";
        case 12:
            return "INFO.NEWS";
        case 28:
            return "INFO.ADVERT";
        case 31:
            return "STATIONNAME.SHORT";
        case 32:
            return "STATIONNAME.LONG";
        case 33:
            return "PROGRAMME.NOW";
        default:
            return "UNKNOWN";
    }
}

void log_rt_plus_slices_locked() {
    if (!g_state.rt_plus_tags_valid || g_state.current_rt_len <= 0) {
        return;
    }

    for (const RtpTag &tag : g_state.rt_plus_tags) {
        if (tag.content_type == 0) {
            continue;
        }
        if (tag.start < 0 || tag.length <= 0 || tag.start + tag.length > g_state.current_rt_len) {
            hal_log("rds", "rt+ slice out of range ct=%d start=%d len=%d rt_len=%d",
                    tag.content_type, tag.start, tag.length, g_state.current_rt_len);
            continue;
        }

        char text[65];
        memcpy(text, g_state.current_rt + tag.start, static_cast<size_t>(tag.length));
        text[tag.length] = '\0';
        hal_log("rds", "rt+ slice %s=`%s`", rtp_content_type_name(tag.content_type), text);
    }
}

bool vendor_set(int id, int value, const char *message) {
    pthread_mutex_lock(&g_state.lock);
    if (g_state.vendor == nullptr) {
        set_error_locked("vendor interface is null");
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    errno = 0;
    const int ret = g_state.vendor->set_fm_ctrl(id, value);
    if (ret < 0) {
        const int saved_errno = errno;
        set_error_locked(message);
        hal_log("vendor", "set id=0x%x value=%d failed, ret=%d errno=%d (%s)",
                id, value, ret, saved_errno, saved_errno ? strerror(saved_errno) : "none");
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    clear_error_locked();
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool vendor_get(int id, int *value, const char *message) {
    pthread_mutex_lock(&g_state.lock);
    if (g_state.vendor == nullptr) {
        set_error_locked("vendor interface is null");
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    errno = 0;
    const int ret = g_state.vendor->get_fm_ctrl(id, value);
    if (ret < 0) {
        const int saved_errno = errno;
        set_error_locked(message);
        hal_log("vendor", "get id=0x%x failed, ret=%d errno=%d (%s)",
                id, ret, saved_errno, saved_errno ? strerror(saved_errno) : "none");
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    clear_error_locked();
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool apply_signal_threshold() {
    return vendor_set(kV4l2CtrlSignalThreshold, kDefaultSignalThreshold, "failed to set signal threshold");
}

bool apply_raw_rds_group_mask() {
    return vendor_set(kV4l2CtrlRdsGroupMask, kHalDefaultRawRdsGroupMask, "failed to set raw rds group mask");
}

bool apply_processed_rds_config(bool auto_af, int rds_standard) {
    if (!vendor_set(kV4l2CtrlRdsStandard, rds_standard, "failed to set rds standard")) {
        return false;
    }

    if (!vendor_set(kV4l2CtrlRdsGroupProc, kHalDefaultRdsGroupProcMask, "failed to set rds groups")) {
        return false;
    }

    if (!vendor_set(kV4l2CtrlAfJump, auto_af ? 1 : 0, "failed to set af jump")) {
        char original_error[sizeof(g_state.last_error)];
        pthread_mutex_lock(&g_state.lock);
        snprintf(original_error, sizeof(original_error), "%s", g_state.last_error);
        pthread_mutex_unlock(&g_state.lock);

        vendor_set(kV4l2CtrlRdsGroupProc, 0, "failed to roll back rds groups");

        pthread_mutex_lock(&g_state.lock);
        snprintf(g_state.last_error, sizeof(g_state.last_error), "%s", original_error);
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    return true;
}

bool apply_post_enable_config() {
    bool auto_af = false;
    bool low_power = false;
    int rds_standard = 0;

    pthread_mutex_lock(&g_state.lock);
    auto_af = g_state.auto_af;
    low_power = g_state.low_power;
    rds_standard = g_state.rds_standard;
    pthread_mutex_unlock(&g_state.lock);

    if (!apply_raw_rds_group_mask()) {
        return false;
    }

    if (low_power) {
        if (!vendor_set(kV4l2CtrlLowPowerMode, 1, "failed to set power mode")) {
            return false;
        }
    } else {
        // Helium initializes its cached power mode to normal and only sends the
        // async event mask when that value changes. Force a low-to-normal edge
        // so stereo, RDS sync, and signal interrupts are armed on first enable.
        // Keep this best-effort because the receiver still works without async
        // transitions, and always attempt to restore the requested normal mode.
        // Reference: https://github.com/LineageOS/android_hardware_qcom_fm/blob/3253b05eba14f36a90058da25627013e354d4f76/helium/radio_helium_hal.c#L1183-L1213
        hal_log("setup", "arm async events through low-to-normal transition");
        vendor_set(kV4l2CtrlLowPowerMode, 1, "failed to enter low power while arming async events");
        vendor_set(kV4l2CtrlLowPowerMode, 0, "failed to restore normal power while arming async events");
    }

    return apply_processed_rds_config(auto_af, rds_standard);
}

int current_frequency_locked() {
    return g_state.current_frequency_khz;
}

int map_spacing_to_vendor(int spacing_khz) {
    switch (spacing_khz) {
        case 50:
            return kHeliumSpacing50Khz;
        case 200:
            return kHeliumSpacing200Khz;
        case 100:
        default:
            return kHeliumSpacing100Khz;
    }
}

void apply_region_profile_locked(StartupRegion region) {
    const RegionProfile &profile = get_region_profile(region);
    g_state.region = region;
    g_state.vendor_region = profile.helium_region;
    g_state.lower_band_khz = static_cast<int>(profile.lower_frequency_khz);
    g_state.upper_band_khz = static_cast<int>(profile.upper_frequency_khz);
    g_state.emphasis = profile.emphasis;
    g_state.rds_standard = profile.rds_standard;
}

int spacing_step_khz_locked() {
    return g_state.spacing_khz;
}

void log_scan_next_cb() {
    int freq = 0;
    if (vendor_get(kV4l2CtrlIrisFreq, &freq, "failed to read scan-next frequency")) {
        hal_log("search", "scan next frequency_khz=%d", freq);
    } else {
        hal_log("search", "scan next");
        return;
    }

    ScanResult result;
    bool complete = false;

    pthread_mutex_lock(&g_state.lock);
    if (g_state.scan.active) {
        if (g_state.scan.stations.add(freq) == ScanAddResult::kFull) {
            hal_log("search", "scan result full, dropping frequency_khz=%d", freq);
        }
        if (g_state.scan.last_frequency_khz > 0 && freq < g_state.scan.last_frequency_khz) {
            g_state.scan.wrapped = true;
        }
        g_state.scan.last_frequency_khz = freq;

        if (g_state.scan.wrapped && freq >= g_state.scan.start_frequency_khz) {
            complete = true;
            g_state.scan.active = false;
            g_state.scan.stations.copy_sorted(&result);
        }
    }
    pthread_mutex_unlock(&g_state.lock);

    if (!complete) {
        return;
    }

    vendor_set(kV4l2CtrlSearchOn, 0, "failed to stop completed scan");
    const std::string frequencies = format_frequency_list_khz(result.frequencies_khz, result.count);

    hal_log("search", "scan complete count=%d frequencies_khz=%s", result.count, frequencies.c_str());
    send_search_done(result.frequencies_khz, result.count);
}

void log_thread_evt_cb(unsigned int evt) {
    hal_log("event", "thread event=%u", evt);
}

void oda_update_cb() {
    hal_log("rds", "oda_update=1");
}

/*
 * RT+: [0]=payload length, [1]=PTY, [2..3]=PI, [4..7]=flags/toggle,
 *      [8..10]=tag 1 (content type, start, length), [11..13]=tag 2, [14]=padding.
 *
 * RT+ tag length is encoded as length-1.
 * Example:
 * RT="Bravo;Valeriy Syutkin - Stil'nyy oranjevyy galstuk"
 * RT+ raw=0f 07 77 56 01 0c 00 01 01 18 19 04 00 14 00
 * tag1 TITLE=(ct=1,start=24,len=25) -> 26 chars
 * tag2 ARTIST=(ct=4,start=0,len=20) -> 21 chars.
 * Byte [5] is the ODA group number (for example 0x0c = 12A); byte [14] can contain stale padding.
 */
void rt_plus_update_cb(char *payload) {
    if (payload == nullptr) {
        hal_log("rds", "rt_plus_update_cb got null");
        return;
    }

    const int len = static_cast<unsigned char>(payload[0]);
    pthread_mutex_lock(&g_state.lock);
    const bool duplicate = is_duplicate_payload_locked(
            &g_state.last_rt_plus_valid, g_state.last_rt_plus, sizeof(g_state.last_rt_plus), payload, len);
    pthread_mutex_unlock(&g_state.lock);
    if (duplicate) {
        return;
    }

    char dump[3 * 32 + 1];
    format_hex_dump(payload, len, dump, sizeof(dump));

    if (len >= 15) {
        const int pty = static_cast<unsigned char>(payload[1]) & 0x1f;
        const int pi = (static_cast<unsigned char>(payload[2]) << 8) | static_cast<unsigned char>(payload[3]);
        const int flags = (static_cast<unsigned char>(payload[4]) << 24) |
                (static_cast<unsigned char>(payload[5]) << 16) |
                (static_cast<unsigned char>(payload[6]) << 8) |
                static_cast<unsigned char>(payload[7]);
        const int tag1_type = static_cast<unsigned char>(payload[8]);
        const int tag1_start = static_cast<unsigned char>(payload[9]);
        const int tag1_len = static_cast<unsigned char>(payload[10]);
        const int tag2_type = static_cast<unsigned char>(payload[11]);
        const int tag2_start = static_cast<unsigned char>(payload[12]);
        const int tag2_len = static_cast<unsigned char>(payload[13]);

        pthread_mutex_lock(&g_state.lock);
        g_state.rt_plus_tags[0] = {tag1_type, tag1_start, tag1_type == 0 ? 0 : tag1_len + 1};
        g_state.rt_plus_tags[1] = {tag2_type, tag2_start, tag2_type == 0 ? 0 : tag2_len + 1};
        g_state.rt_plus_tags_valid = true;
        log_rt_plus_slices_locked();
        pthread_mutex_unlock(&g_state.lock);

        hal_log("rds", "rt+ len=%d pi=%04x pty=%d flags=0x%08x tag1=(ct=%d,start=%d,len=%d) tag2=(ct=%d,start=%d,len=%d) data=%s%s",
                len, pi, pty, flags,
                tag1_type, tag1_start, tag1_type == 0 ? 0 : tag1_len + 1,
                tag2_type, tag2_start, tag2_type == 0 ? 0 : tag2_len + 1,
                dump, len > 32 ? " ..." : "");
        return;
    }

    if (len >= 4) {
        const int pty = static_cast<unsigned char>(payload[1]) & 0x1f;
        const int pi = (static_cast<unsigned char>(payload[2]) << 8) | static_cast<unsigned char>(payload[3]);
        hal_log("rds", "rt+ len=%d pi=%04x pty=%d data=%s%s",
                len, pi, pty, dump, len > 32 ? " ..." : "");
        return;
    }

    hal_log("rds", "rt+ len=%d data=%s%s", len, dump, len > 32 ? " ..." : "");
}

void ert_update_cb(char *payload) {
    log_length_prefixed_payload("rds", "ert_update_cb", payload, 3);
}

void rds_grp_cntrs_rsp_cb(char *payload) {
    log_length_prefixed_payload("rds", "rds_grp_cntrs_rsp_cb", payload);
}

void rds_grp_cntrs_ext_rsp_cb(char *payload) {
    log_length_prefixed_payload("rds", "rds_grp_cntrs_ext_rsp_cb", payload);
}

void fm_peek_rsp_cb(char *payload) {
    log_length_prefixed_payload("vendor", "fm_peek_rsp_cb", payload);
}

void fm_ssbi_peek_rsp_cb(char *payload) {
    log_length_prefixed_payload("vendor", "fm_ssbi_peek_rsp_cb", payload);
}

void fm_agc_gain_rsp_cb(char *payload) {
    log_length_prefixed_payload("vendor", "fm_agc_gain_rsp_cb", payload);
}

void fm_ch_det_th_rsp_cb(char *payload) {
    log_length_prefixed_payload("vendor", "fm_ch_det_th_rsp_cb", payload);
}

/*
 * ECC callback carries RDS group 1A:
 * [0]=12
 * [1]=PTY
 * [2..3]=PI
 * [4..5]=variant
 * [6..7]=flags/reserved
 * [8..9]=slow labelling
 * [10..11]=block D.
 *
 * The slow-labelling low byte is ECC only when variant == 0. Other variants
 * are broadcaster/vendor data and are ignored to avoid log spam.
 */
void ext_country_code_cb(char *payload) {
    if (payload == nullptr) {
        hal_log("rds", "ext_country_code_cb got null");
        return;
    }

    const int len = static_cast<unsigned char>(payload[0]);
    pthread_mutex_lock(&g_state.lock);
    const bool duplicate = is_duplicate_payload_locked(
            &g_state.last_ecc_valid, g_state.last_ecc, sizeof(g_state.last_ecc), payload, len);
    pthread_mutex_unlock(&g_state.lock);
    if (duplicate) {
        return;
    }

    char dump[3 * 32 + 1];
    format_hex_dump(payload, len, dump, sizeof(dump));

    if (len >= 12) {
        const int pty = static_cast<unsigned char>(payload[1]) & 0x1f;
        const int pi = (static_cast<unsigned char>(payload[2]) << 8) | static_cast<unsigned char>(payload[3]);
        const int variant = (static_cast<unsigned char>(payload[4]) << 8) | static_cast<unsigned char>(payload[5]);
        const int slow_labelling =
                (static_cast<unsigned char>(payload[8]) << 8) | static_cast<unsigned char>(payload[9]);
        const int block_d = (static_cast<unsigned char>(payload[10]) << 8) | static_cast<unsigned char>(payload[11]);

        if (variant == 0) {
            const int country_code = (pi >> 12) & 0x0f;
            const int ecc = slow_labelling & 0xff;
            char country[3];
            if (decode_rds_country_iso(ecc, country_code, country)) {
                hal_log("rds", "ecc len=%d pi=%04x pty=%d cc=0x%x ecc=0x%02x country=%s sl=0x%04x block_d=0x%04x data=%s%s",
                        len, pi, pty, country_code, ecc, country, slow_labelling, block_d, dump, len > 32 ? " ..." : "");
                radio_state_patch_t patch = radio_state_patch_empty();
                patch.country = country;
                send_radio_state_patch(&patch);
            } else {
                hal_log("rds", "ecc len=%d pi=%04x pty=%d cc=0x%x ecc=0x%02x country=unknown sl=0x%04x block_d=0x%04x data=%s%s",
                        len, pi, pty, country_code, ecc, slow_labelling, block_d, dump, len > 32 ? " ..." : "");
            }
            return;
        }

        return;
    }

    hal_log("rds", "ecc len=%d data=%s%s", len, dump, len > 32 ? " ..." : "");
}

void fm_get_sig_thres_cb(int value, int status) {
    hal_log("vendor", "fm_get_sig_thres_cb value=%d status=%d", value, status);
}

void fm_get_ch_det_thr_cb(int value, int status) {
    hal_log("vendor", "fm_get_ch_det_thr_cb value=%d status=%d", value, status);
}

void fm_def_data_read_cb(int value, int status) {
    hal_log("vendor", "fm_def_data_read_cb value=%d status=%d", value, status);
}

void fm_get_blend_cb(int value, int status) {
    hal_log("vendor", "fm_get_blend_cb value=%d status=%d", value, status);
}

void fm_set_ch_det_thr_cb(int status) {
    hal_log("vendor", "fm_set_ch_det_thr_cb status=%d", status);
}

void fm_def_data_write_cb(int status) {
    hal_log("vendor", "fm_def_data_write_cb status=%d", status);
}

void fm_set_blend_cb(int status) {
    hal_log("vendor", "fm_set_blend_cb status=%d", status);
}

void fm_get_station_param_cb(int value, int status) {
    pthread_mutex_lock(&g_state.lock);

    const bool pending = g_state.rmssi.pending;
    const int requested_frequency = g_state.rmssi.request_frequency_khz;
    const bool publish = pending &&
            g_state.enabled &&
            !g_state.rmssi.paused &&
            !g_state.scan.active &&
            requested_frequency == g_state.current_frequency_khz;

    g_state.rmssi.clear_request();

    pthread_mutex_unlock(&g_state.lock);

    const unsigned int raw_value = static_cast<unsigned int>(value) & 0xffU;
    const int signed_value = decode_rmssi(value);

    hal_log("metric", "%s status=%d value=%d raw=0x%02x",
            pending ? "rmssi" : "unexpected", status, signed_value, raw_value);

    if (status == 0 && publish) {
        radio_state_patch_t patch = radio_state_patch_empty();
        patch.rmssi = signed_value;
        send_radio_state_patch(&patch);
    }
}

void fm_get_station_debug_param_cb(int value, int status) {
    hal_log("vendor", "fm_get_station_debug_param_cb value=%d status=%d", value, status);
}

void enable_softmute_cb(int status) {
    hal_log("audio", "soft_mute status=%d", status);
}

void rds_avail_status_cb(bool rds_available) {
    hal_log("event", "rds_sync=%d", rds_available ? 1 : 0);
}

void enable_slimbus_cb(int status) {
    hal_log("event", "slimbus status=%d", status);
    pthread_mutex_lock(&g_state.lock);
    g_state.audio.slimbus_enabled = status == 0;
    pthread_mutex_unlock(&g_state.lock);
}

void enabled_cb() {
    hal_log("event", "FM enabled");
    pthread_mutex_lock(&g_state.lock);
    g_state.enabled = true;
    g_state.last_enabled_cb_ms = monotonic_ms();
    pthread_cond_broadcast(&g_state.cond);
    pthread_mutex_unlock(&g_state.lock);
}

void disabled_cb() {
    hal_log("event", "FM disabled");

    pthread_mutex_lock(&g_state.lock);
    g_state.enabled = false;
    g_state.audio.mode_valid = false;
    g_state.rmssi.clear_request();
    g_state.rmssi.paused = true;
    pthread_cond_broadcast(&g_state.cond);
    pthread_mutex_unlock(&g_state.lock);

    send_native_event("disabled");
}

void tune_cb(int freq) {
    hal_log("event", "tune frequency_khz=%d", freq);
    pthread_mutex_lock(&g_state.lock);
    g_state.current_frequency_khz = freq;
    g_state.rmssi.paused = false;
    g_state.last_tune_cb_ms = monotonic_ms();
    reset_search_result_locked();
    reset_rds_dedup_locked();
    pthread_mutex_unlock(&g_state.lock);
    radio_state_patch_t patch = radio_state_patch_empty();
    patch.frequency_khz = freq;
    patch.ps = patch.rt = patch.pi = patch.country = "";
    patch.af_count = patch.pty = 0;
    send_radio_state_patch(&patch);

    // The tune callback is the first authoritative point at which RMSSI belongs
    // to the new station. Refresh now instead of waiting for the periodic tick.
    fm2_backend_request_rmssi();
}

void seek_complete_cb(int freq) {
    int current = 0;
    if (vendor_get(kV4l2CtrlIrisFreq, &current, "failed to read seek-complete frequency")) {
        hal_log("event", "seek complete frequency_khz=%d current_frequency_khz=%d", freq, current);
    } else {
        hal_log("event", "seek complete frequency_khz=%d", freq);
    }

    ScanResult result;
    bool scan_complete = false;

    pthread_mutex_lock(&g_state.lock);
    g_state.current_frequency_khz = freq;
    g_state.rmssi.paused = false;
    g_state.last_seek_cb_ms = monotonic_ms();
    reset_search_result_locked();
    reset_rds_dedup_locked();

    // Helium reports terminal SEARCH_COMPLETE through the seek callback and may
    // repeat it, so claim the active scan under the lock before sending results.
    if (g_state.scan.active) {
        scan_complete = true;
        g_state.scan.active = false;
        g_state.scan.stations.copy_sorted(&result);
    }
    pthread_mutex_unlock(&g_state.lock);

    if (scan_complete) {
        const std::string frequencies = format_frequency_list_khz(result.frequencies_khz, result.count);
        hal_log("search", "scan complete source=seek_complete count=%d frequencies_khz=%s",
                result.count, frequencies.c_str());
        send_search_done(result.frequencies_khz, result.count);
        return;
    }

    radio_state_patch_t patch = radio_state_patch_empty();

    patch.frequency_khz = freq;
    patch.ps = patch.rt = patch.pi = patch.country = "";
    patch.af_count = patch.pty = 0;

    send_radio_state_patch(&patch);
}

void stereo_status_cb(bool stereo) {
    hal_log("event", "stereo=%d", stereo);
    pthread_mutex_lock(&g_state.lock);
    g_state.audio.stereo = stereo;
    pthread_mutex_unlock(&g_state.lock);
    radio_state_patch_t patch = radio_state_patch_empty();
    patch.stereo = stereo ? 1 : 0;
    send_radio_state_patch(&patch);
}

/*
 * PS:
 * [0]=PS block count
 * [1]=PTY
 * [2..3]=PI
 * [4]=header,
 * [5..]=one or more 8-byte Program Service name blocks.
 *
 * Qualcomm HAL keeps PTY/PI in the same buffer, so we can update all three app fields here.
 */
void ps_update_cb(char *ps) {
    if (ps == nullptr) {
        hal_log("rds", "ps update got null");
        return;
    }

    RdsTextPayload parsed;
    if (!parse_rds_text_payload(
            reinterpret_cast<const unsigned char *>(ps),
            kUnknownRdsPayloadLen,
            RdsTextPayloadKind::kProgramService,
            sizeof(parsed.text) - 1,
            &parsed
    )) {
        hal_log("rds", "invalid ps count=%d", static_cast<unsigned char>(ps[0]) & 0x0f);
        return;
    }

    hal_log("rds", "ps count=%d pi=%04x pty=%d text=`%s` (len=%d)",
            parsed.block_count, parsed.pi, parsed.pty, parsed.text, parsed.text_len);
    char pi[16];
    snprintf(pi, sizeof(pi), "%x", parsed.pi);
    radio_state_patch_t patch = radio_state_patch_empty();
    patch.ps = parsed.text;
    patch.pty = parsed.pty;
    patch.pi = pi;
    send_radio_state_patch(&patch);
}

/*
 * RT:
 * [0]=text length
 * [1..4]=metadata/header
 * [5..]=RadioText.
 *
 * The HAL-provided length is clamped to the RDS 64-character RT limit before copying.
 */
void rt_update_cb(char *rt) {
    if (rt == nullptr) {
        hal_log("rds", "rt update got null");
        return;
    }

    RdsTextPayload parsed;
    if (!parse_rds_text_payload(
            reinterpret_cast<const unsigned char *>(rt),
            kUnknownRdsPayloadLen,
            RdsTextPayloadKind::kRadioText,
            sizeof(parsed.text) - 1,
            &parsed
    ) || parsed.text_len == 0) {
        hal_log("rds", "invalid rt len=%d", static_cast<unsigned char>(rt[0]) & 0x7f);
        return;
    }

    pthread_mutex_lock(&g_state.lock);
    snprintf(g_state.current_rt, sizeof(g_state.current_rt), "%s", parsed.text);
    g_state.current_rt_len = parsed.text_len;
    log_rt_plus_slices_locked();
    pthread_mutex_unlock(&g_state.lock);

    hal_log("rds", "rt text=`%s` (len=%d)", parsed.text, parsed.text_len);
    radio_state_patch_t patch = radio_state_patch_empty();
    patch.rt = parsed.text;
    send_radio_state_patch(&patch);
}

/*
 * AF list:
 * [0..3]=tuned frequency
 * [4..5]=PI
 * [6]=AF count,
 * [7..]=int32 kHz frequency entries from the vendor HAL.
 */
void af_update_cb(uint16_t *raw) {
    if (raw == nullptr) {
        return;
    }

    RdsAfList af;
    if (!parse_rds_af_payload(
            reinterpret_cast<const unsigned char *>(raw),
            kUnknownRdsPayloadLen,
            &af
    )) {
        const hci_ev_af_list *raw_af = reinterpret_cast<const hci_ev_af_list *>(raw);
        hal_log("af", "invalid size=%u", raw_af->af_size);
        return;
    }

    const std::string frequencies = format_frequency_list_khz(af.frequencies_khz, af.count);

    hal_log("af", "result count=%d frequencies_khz=%s", af.count, frequencies.c_str());
    radio_state_patch_t patch = radio_state_patch_empty();
    patch.af_khz = af.frequencies_khz;
    patch.af_count = af.count;
    send_radio_state_patch(&patch);
}

/*
 * Search list:
 * [0]=station count
 * [1..]=big-endian 16-bit relative offsets.
 *
 * Offsets are measured from the current lower band edge in 50 kHz units.
 */
void search_list_cb(uint16_t *raw) {
    if (raw == nullptr) {
        return;
    }

    int lower_band = 87500;
    pthread_mutex_lock(&g_state.lock);
    lower_band = g_state.lower_band_khz;
    pthread_mutex_unlock(&g_state.lock);

    RdsSearchList list;
    if (!parse_rds_search_list_payload(
            reinterpret_cast<const unsigned char *>(raw),
            kUnknownRdsPayloadLen,
            RdsSearchListKind::kRelativeOffsets,
            lower_band,
            &list
    )) {
        hal_log("search", "invalid result");
        return;
    }

    if (list.count <= 0) {
        pthread_mutex_lock(&g_state.lock);
        const bool duplicate = g_state.last_search_payload_valid && g_state.last_search_payload[0] == '\0';
        g_state.last_search_payload_valid = true;
        g_state.last_search_payload[0] = '\0';
        pthread_mutex_unlock(&g_state.lock);
        if (duplicate) {
            return;
        }

        hal_log("search", "empty result");
        send_search_done(nullptr, 0);
        return;
    }

    const std::string frequencies = format_frequency_list_khz(list.frequencies_khz, list.count);

    // Qualcomm HAL can replay the last search-list callback after the real
    // search result, typically while processing the next command-complete
    // event. The callback buffer is malloc/free-owned by the HAL, so dedupe by
    // decoded payload instead of pointer or event ordering.
    pthread_mutex_lock(&g_state.lock);
    const bool duplicate = g_state.last_search_payload_valid &&
            strcmp(g_state.last_search_payload, frequencies.c_str()) == 0;
    if (!duplicate) {
        snprintf(g_state.last_search_payload, sizeof(g_state.last_search_payload), "%s", frequencies.c_str());
        g_state.last_search_payload_valid = true;
    }
    pthread_mutex_unlock(&g_state.lock);
    if (duplicate) {
        return;
    }

    hal_log("search", "result count=%d reported=%d frequencies_khz=%s", list.count, list.reported_count, frequencies.c_str());
    send_search_done(list.frequencies_khz, list.count);
}

static fm_hal_callbacks_t g_callbacks = {
    sizeof(fm_hal_callbacks_t),
    enabled_cb,
    tune_cb,
    seek_complete_cb,
    log_scan_next_cb,
    search_list_cb,
    stereo_status_cb,
    rds_avail_status_cb,
    af_update_cb,
    rt_update_cb,
    ps_update_cb,
    oda_update_cb,
    rt_plus_update_cb,
    ert_update_cb,
    disabled_cb,
    rds_grp_cntrs_rsp_cb,
    rds_grp_cntrs_ext_rsp_cb,
    fm_peek_rsp_cb,
    fm_ssbi_peek_rsp_cb,
    fm_agc_gain_rsp_cb,
    fm_ch_det_th_rsp_cb,
    ext_country_code_cb,
    log_thread_evt_cb,
    fm_get_sig_thres_cb,
    fm_get_ch_det_thr_cb,
    fm_def_data_read_cb,
    fm_get_blend_cb,
    fm_set_ch_det_thr_cb,
    fm_def_data_write_cb,
    fm_set_blend_cb,
    fm_get_station_param_cb,
    fm_get_station_debug_param_cb,
    enable_slimbus_cb,
    enable_softmute_cb,
};

bool apply_runtime_config() {
    int spacing = 0;
    int region = 0;
    int lower = 0;
    int upper = 0;
    int stereo = 0;
    int soft_mute = 0;
    int antenna = 0;
    int emphasis = 0;
    int rds_standard = 0;

    pthread_mutex_lock(&g_state.lock);
    spacing = g_state.vendor_spacing;
    region = g_state.vendor_region;
    lower = g_state.lower_band_khz;
    upper = g_state.upper_band_khz;
    stereo = g_state.audio.mode_stereo ? 1 : 0;
    soft_mute = g_state.audio.soft_mute ? 1 : 0;
    antenna = g_state.antenna;
    emphasis = g_state.emphasis;
    rds_standard = g_state.rds_standard;
    pthread_mutex_unlock(&g_state.lock);

    hal_log("setup", "runtime region=%d lower_khz=%d upper_khz=%d spacing=%d emphasis=%d rds=%d stereo=%d soft_mute=%d antenna=%d",
            region, lower, upper, spacing, emphasis, rds_standard, stereo, soft_mute, antenna);

    if (
        !vendor_set(kV4l2CtrlEmphasis, emphasis, "failed to set emphasis") ||
        !vendor_set(kV4l2CtrlRdsStandard, rds_standard, "failed to set rds standard") ||
        !vendor_set(kV4l2CtrlChannelSpacing, spacing, "failed to set channel spacing") ||
        !vendor_set(kV4l2CtrlIrisUpperBand, upper, "failed to set upper band") ||
        !vendor_set(kV4l2CtrlIrisLowerBand, lower, "failed to set lower band") ||
        !vendor_set(kV4l2CtrlRegion, region, "failed to set region") ||
        !vendor_set(kV4l2CtrlIrisAudioMode, stereo, "failed to set stereo mode") ||
        !vendor_set(kV4l2CtrlAntenna, antenna, "failed to set antenna") ||
        !apply_signal_threshold() ||
        !vendor_set(kV4l2CtrlSoftMute, soft_mute, "failed to set soft mute")
    ) {
        return false;
    }

    pthread_mutex_lock(&g_state.lock);
    g_state.audio.mode_valid = true;
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

}  // namespace

bool fm2_backend_init() {
    pthread_mutex_lock(&g_state.lock);
    if (g_state.initialized) {
        clear_error_locked();
        pthread_mutex_unlock(&g_state.lock);
        return true;
    }

    apply_region_profile_locked(g_state.region);
    g_state.vendor_spacing = map_spacing_to_vendor(g_state.spacing_khz);

    g_state.lib_handle = dlopen(kFmLibraryName, RTLD_NOW);
    if (g_state.lib_handle == nullptr) {
        const char *err = dlerror();
        hal_log("open", "dlopen failed for %s: %s", kFmLibraryName, err ? err : "(unknown)");
        set_error_locked(err ? err : "dlopen failed");
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }
    g_state.vendor = (fm_interface_t *) dlsym(g_state.lib_handle, kFmLibrarySymbol);
    if (g_state.vendor == nullptr) {
        const char *err = dlerror();
        hal_log("open", "dlsym failed for %s: %s", kFmLibrarySymbol, err ? err : "(unknown)");
        set_error_locked(err ? err : "dlsym failed");
        dlclose(g_state.lib_handle);
        g_state.lib_handle = nullptr;
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }
    const int ret = g_state.vendor->hal_init(&g_callbacks);
    if (ret != 0) {
        set_error_locked("hal_init failed");
        dlclose(g_state.lib_handle);
        g_state.lib_handle = nullptr;
        g_state.vendor = nullptr;
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    g_state.initialized = true;
    clear_error_locked();
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool fm2_backend_configure_startup(const StartupConfig &config) {
    pthread_mutex_lock(&g_state.lock);
    apply_region_profile_locked(config.region);
    g_state.spacing_khz = config.spacing_khz;
    g_state.vendor_spacing = map_spacing_to_vendor(config.spacing_khz);
    g_state.audio.mode_stereo = config.stereo;
    g_state.audio.mode_valid = false;
    g_state.audio.soft_mute = config.soft_mute;
    g_state.antenna = config.antenna;
    g_state.auto_af = config.auto_af;
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool fm2_backend_enable() {
    hal_log("enable", "requested");
    if (!fm2_backend_init()) {
        return false;
    }

    pthread_mutex_lock(&g_state.lock);
    g_state.enabled = false;
    g_state.last_enabled_cb_ms = 0;
    g_state.rmssi.clear_request();
    g_state.rmssi.paused = true;
    pthread_mutex_unlock(&g_state.lock);

    if (!fm2_backend_set_slimbus(true)) {
        hal_log("enable", "failed to enable slimbus before receiver state");
    }

    if (!vendor_set(kV4l2CtrlState, kFmRxState, "failed to enable receiver")) {
        return false;
    }

    if (!fm2_backend_wait_enabled(kEnableWaitTimeoutMs)) {
        return false;
    }

    if (!apply_runtime_config()) {
        return false;
    }

    fm2_backend_log_snapshot("after-runtime-config");
    if (!apply_post_enable_config()) {
        return false;
    }
    hal_log("enable", "accepted");
    return true;
}

bool fm2_backend_wait_enabled(int timeout_ms) {
    struct timespec deadline;
    clock_gettime(CLOCK_REALTIME, &deadline);
    deadline.tv_sec += timeout_ms / 1000;
    deadline.tv_nsec += (timeout_ms % 1000) * 1000000L;
    if (deadline.tv_nsec >= 1000000000L) {
        deadline.tv_sec += 1;
        deadline.tv_nsec -= 1000000000L;
    }

    pthread_mutex_lock(&g_state.lock);
    while (!g_state.enabled) {
        const int wait_ret = pthread_cond_timedwait(&g_state.cond, &g_state.lock, &deadline);
        if (wait_ret != 0) {
            set_error_locked("timed out waiting for enabled_cb");
            pthread_mutex_unlock(&g_state.lock);
            return false;
        }
    }
    clear_error_locked();
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool fm2_backend_disable() {
    hal_log("disable", "requested");
    pthread_mutex_lock(&g_state.lock);
    g_state.rmssi.paused = true;
    g_state.rmssi.clear_request();
    pthread_mutex_unlock(&g_state.lock);

    const bool disabled = vendor_set(kV4l2CtrlState, 0, "failed to disable receiver");
    const bool slimbus = fm2_backend_set_slimbus(false);
    const bool accepted = disabled && slimbus;

    if (accepted) {
        hal_log("disable", "accepted");
    }

    return accepted;
}

bool fm2_backend_set_frequency(uint32_t frequency_khz) {
    hal_log("tune", "request frequency_khz=%u", frequency_khz);

    pthread_mutex_lock(&g_state.lock);
    g_state.rmssi.paused = true;
    pthread_mutex_unlock(&g_state.lock);

    if (!vendor_set(kV4l2CtrlIrisFreq, static_cast<int>(frequency_khz), "failed to tune")) {
        pthread_mutex_lock(&g_state.lock);
        g_state.rmssi.paused = false;
        pthread_mutex_unlock(&g_state.lock);

        return false;
    }
    hal_log("tune", "request frequency_khz=%u accepted", frequency_khz);

    pthread_mutex_lock(&g_state.lock);
    g_state.current_frequency_khz = static_cast<int>(frequency_khz);
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

uint32_t fm2_backend_get_frequency() {
    int freq = 0;

    if (!vendor_get(kV4l2CtrlIrisFreq, &freq, "failed to read frequency")) {
        pthread_mutex_lock(&g_state.lock);
        const int cached = current_frequency_locked();
        pthread_mutex_unlock(&g_state.lock);
        hal_log("tune", "get frequency failed, using cached (frequency_khz=%d)", cached);
        return cached > 0 ? static_cast<uint32_t>(cached) : 0;
    }

    if (freq <= 0) {
        pthread_mutex_lock(&g_state.lock);
        const int cached = current_frequency_locked();
        clear_error_locked();
        pthread_mutex_unlock(&g_state.lock);
        hal_log("tune", "invalid frequency_khz=%d, using cached (frequency_khz=%d)", freq, cached);
        return cached > 0 ? static_cast<uint32_t>(cached) : 0;
    }

    pthread_mutex_lock(&g_state.lock);
    g_state.current_frequency_khz = freq;
    clear_error_locked();
    pthread_mutex_unlock(&g_state.lock);
    return static_cast<uint32_t>(freq);
}

bool fm2_backend_jump(int direction, uint32_t *new_frequency) {
    pthread_mutex_lock(&g_state.lock);
    const int step = spacing_step_khz_locked();
    const int lower = g_state.lower_band_khz;
    const int upper = g_state.upper_band_khz;
    pthread_mutex_unlock(&g_state.lock);

    const int current = static_cast<int>(fm2_backend_get_frequency());
    if (current <= 0) {
        return false;
    }

    int target = current + (step * (direction >= 0 ? 1 : -1));
    if (target > upper) {
        target = lower;
    } else if (target < lower) {
        target = upper;
    }

    if (!fm2_backend_set_frequency(target)) {
        return false;
    }

    if (new_frequency != nullptr) {
        *new_frequency = static_cast<uint32_t>(target);
    }
    return true;
}

bool fm2_backend_seek(int direction) {
    hal_log("search", "seek requested direction=%d dwell=%d", direction, kDefaultSeekDwell);

    pthread_mutex_lock(&g_state.lock);
    g_state.rmssi.paused = true;
    pthread_mutex_unlock(&g_state.lock);

    const bool ok = vendor_set(kV4l2CtrlSearchMode, kSearchModeSeek, "failed to set seek mode") &&
                    vendor_set(kV4l2CtrlScanDwell, kDefaultSeekDwell, "failed to set seek dwell") &&
                    vendor_set(kV4l2CtrlIrisSeek, direction >= 0 ? 1 : 0, "failed to start seek");
    if (ok) {
        hal_log("search", "seek direction=%d accepted", direction);
    } else {
        pthread_mutex_lock(&g_state.lock);
        g_state.rmssi.paused = false;
        pthread_mutex_unlock(&g_state.lock);
    }
    return ok;
}

bool fm2_backend_search() {
    pthread_mutex_lock(&g_state.lock);
    const int start_frequency = g_state.lower_band_khz;
    reset_search_result_locked();
    reset_scan_locked();
    g_state.scan.active = true;
    g_state.scan.start_frequency_khz = start_frequency;
    g_state.scan.last_frequency_khz = start_frequency;
    pthread_mutex_unlock(&g_state.lock);

    hal_log("search", "scan start frequency_khz=%d", start_frequency);

    const bool ok = vendor_set(kV4l2CtrlIrisFreq, start_frequency, "failed to tune scan start") &&
                    vendor_set(kV4l2CtrlSearchMode, kSearchModeScan, "failed to set scan mode") &&
                    vendor_set(kV4l2CtrlScanDwell, 1, "failed to set scan dwell") &&
                    vendor_set(kV4l2CtrlIrisSeek, 1, "failed to start scan");
    if (!ok) {
        pthread_mutex_lock(&g_state.lock);
        reset_scan_locked();
        pthread_mutex_unlock(&g_state.lock);
    }
    return ok;
}

bool fm2_backend_cancel_search() {
    hal_log("search", "cancel requested");
    pthread_mutex_lock(&g_state.lock);
    reset_scan_locked();
    pthread_mutex_unlock(&g_state.lock);
    return vendor_set(kV4l2CtrlSearchOn, 0, "failed to cancel search");
}

bool fm2_backend_set_stereo(bool enabled) {
    pthread_mutex_lock(&g_state.lock);
    const bool already_set = g_state.audio.mode_valid && g_state.audio.mode_stereo == enabled;
    g_state.audio.mode_valid = true;
    g_state.audio.mode_stereo = enabled;
    pthread_mutex_unlock(&g_state.lock);

    if (already_set) {
        hal_log("audio", "set stereo=%d skipped", enabled ? 1 : 0);
        return true;
    }

    hal_log("audio", "set stereo=%d", enabled ? 1 : 0);
    return vendor_set(kV4l2CtrlIrisAudioMode, enabled ? 1 : 0, "failed to set stereo mode");
}

bool fm2_backend_set_spacing_khz(int spacing_khz) {
    hal_log("setup", "set spacing_khz=%d", spacing_khz);
    pthread_mutex_lock(&g_state.lock);
    g_state.spacing_khz = spacing_khz;
    g_state.vendor_spacing = map_spacing_to_vendor(spacing_khz);
    const int vendor_spacing = g_state.vendor_spacing;
    pthread_mutex_unlock(&g_state.lock);
    return vendor_set(kV4l2CtrlChannelSpacing, vendor_spacing, "failed to set spacing");
}

bool fm2_backend_set_region(StartupRegion startup_region) {
    hal_log("setup", "set region=%s", get_region_name(startup_region));
    pthread_mutex_lock(&g_state.lock);
    apply_region_profile_locked(startup_region);
    const int region = g_state.vendor_region;
    const int lower = g_state.lower_band_khz;
    const int upper = g_state.upper_band_khz;
    const int emphasis = g_state.emphasis;
    const int rds_standard = g_state.rds_standard;
    const int current_frequency = g_state.current_frequency_khz;
    pthread_mutex_unlock(&g_state.lock);

    hal_log("setup", "apply region=%d lower_khz=%d upper_khz=%d emphasis=%d rds=%d",
            region, lower, upper, emphasis, rds_standard);
    const bool configured =
            vendor_set(kV4l2CtrlIrisUpperBand, upper, "failed to set upper band") &&
            vendor_set(kV4l2CtrlIrisLowerBand, lower, "failed to set lower band") &&
            vendor_set(kV4l2CtrlEmphasis, emphasis, "failed to set emphasis") &&
            vendor_set(kV4l2CtrlRdsStandard, rds_standard, "failed to set rds standard") &&
            vendor_set(kV4l2CtrlRegion, region, "failed to set region");
    if (!configured || current_frequency <= 0) {
        return configured;
    }

    const RegionProfile &profile = get_region_profile(startup_region);
    const uint32_t target_frequency = clamp_frequency_to_region(profile, static_cast<uint32_t>(current_frequency));
    return target_frequency == static_cast<uint32_t>(current_frequency) ||
           fm2_backend_set_frequency(target_frequency);
}

bool fm2_backend_set_antenna(int antenna) {
    hal_log("setup", "set antenna=%d", antenna);
    pthread_mutex_lock(&g_state.lock);
    g_state.antenna = antenna;
    pthread_mutex_unlock(&g_state.lock);
    return vendor_set(kV4l2CtrlAntenna, antenna, "failed to set antenna");
}

bool fm2_backend_set_power_mode(bool low_power) {
    hal_log("setup", "set low_power=%d", low_power ? 1 : 0);
    pthread_mutex_lock(&g_state.lock);
    g_state.low_power = low_power;
    pthread_mutex_unlock(&g_state.lock);
    return vendor_set(kV4l2CtrlLowPowerMode, low_power ? 1 : 0, "failed to set power mode");
}

bool fm2_backend_set_auto_af(bool enabled) {
    hal_log("af", "set auto=%d", enabled ? 1 : 0);
    pthread_mutex_lock(&g_state.lock);
    g_state.auto_af = enabled;
    pthread_mutex_unlock(&g_state.lock);
    return vendor_set(kV4l2CtrlAfJump, enabled ? 1 : 0, "failed to set auto af");
}

bool fm2_backend_set_soft_mute(bool enabled) {
    hal_log("audio", "set soft_mute=%d", enabled ? 1 : 0);
    if (!vendor_set(kV4l2CtrlSoftMute, enabled ? 1 : 0, "failed to set soft mute")) {
        return false;
    }

    pthread_mutex_lock(&g_state.lock);
    g_state.audio.soft_mute = enabled;
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool fm2_backend_set_slimbus(bool enabled) {
    hal_log("setup", "set slimbus=%d", enabled ? 1 : 0);
    if (!vendor_set(kV4l2CtrlEnableSlimbus, enabled ? 1 : 0, "failed to set slimbus")) {
        return false;
    }

    pthread_mutex_lock(&g_state.lock);
    g_state.audio.slimbus_enabled = enabled;
    pthread_mutex_unlock(&g_state.lock);
    return true;
}

bool fm2_backend_raw_set(int id, int value) {
    return vendor_set(id, value, "failed raw set");
}

bool fm2_backend_raw_get(int id, int *value) {
    return vendor_get(id, value, "failed raw get");
}

bool fm2_backend_request_rmssi() {
    const uint64_t requested_at = monotonic_ms();

    pthread_mutex_lock(&g_state.lock);

    if (
            !g_state.enabled ||
            g_state.scan.active ||
            g_state.rmssi.paused ||
            g_state.vendor == nullptr
    ) {
        pthread_mutex_unlock(&g_state.lock);
        return false;
    }

    if (g_state.rmssi.pending) {
        const uint64_t elapsed = requested_at - g_state.rmssi.requested_at_ms;

        if (
                elapsed >= kRmssiRequestTimeoutMs &&
                !g_state.rmssi.timeout_logged
        ) {
            hal_log("rmssi", "request still pending after %llu ms", static_cast<unsigned long long>(elapsed));
            g_state.rmssi.timeout_logged = true;
        }

        pthread_mutex_unlock(&g_state.lock);

        return false;
    }

    g_state.rmssi.pending = true;
    g_state.rmssi.requested_at_ms = requested_at;
    g_state.rmssi.request_frequency_khz = g_state.current_frequency_khz;
    g_state.rmssi.timeout_logged = false;

    fm_interface_t *vendor = g_state.vendor;
    pthread_mutex_unlock(&g_state.lock);

    int unused = 0;
    errno = 0;

    const int ret = vendor->get_fm_ctrl(kV4l2CtrlIrisRmssi, &unused);
    if (ret < 0) {
        const int saved_errno = errno;

        pthread_mutex_lock(&g_state.lock);

        if (g_state.rmssi.pending) {
            g_state.rmssi.clear_request();
        }

        pthread_mutex_unlock(&g_state.lock);

        hal_log("vendor", "get id=0x%x failed, ret=%d errno=%d (%s)", kV4l2CtrlIrisRmssi, ret, saved_errno, saved_errno ? strerror(saved_errno) : "none");

        return false;
    }

    hal_log("rmssi", "requested");
    return true;
}

bool fm2_backend_log_snapshot(const char *reason) {
    struct CtlProbe {
        int id;
        const char *name;
    };

    static const CtlProbe probes[] = {
        {kV4l2CtrlState, "state"},
        {kV4l2CtrlRegion, "region"},
        {kV4l2CtrlEmphasis, "emphasis"},
        {kV4l2CtrlRdsStandard, "rds_std"},
        {kV4l2CtrlChannelSpacing, "spacing"},
        {kV4l2CtrlSignalThreshold, "signal_th"},
        {kV4l2CtrlRdsOn, "rds_on"},
        {kV4l2CtrlRdsGroupMask, "rds_mask"},
        {kV4l2CtrlRdsGroupProc, "rds_proc"},
        {kV4l2CtrlLowPowerMode, "lp_mode"},
        {kV4l2CtrlAntenna, "antenna"},
        {kV4l2CtrlAfJump, "af_jump"},
        {kV4l2CtrlSoftMute, "soft_mute"},
        {kV4l2CtrlIrisFreq, "freq"},
    };

    bool ok = true;
    hal_log("snap", "reason=%s", reason ? reason : "(null)");
    for (const CtlProbe &probe : probes) {
        int value = 0;
        const bool probe_ok = vendor_get(probe.id, &value, "failed snapshot read");
        ok &= probe_ok;
        hal_log("snap", "%-9s id=0x%07x value=%d (ok=%d)", probe.name, probe.id, value, probe_ok ? 1 : 0);
    }

    return ok;
}

const char *fm2_backend_last_error() {
    return g_state.last_error;
}
