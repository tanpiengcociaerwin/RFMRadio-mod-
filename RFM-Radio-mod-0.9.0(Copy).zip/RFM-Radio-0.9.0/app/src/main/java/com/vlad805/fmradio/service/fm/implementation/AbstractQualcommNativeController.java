package com.vlad805.fmradio.service.fm.implementation;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.system.ErrnoException;
import android.system.Os;
import android.util.Log;

import com.vlad805.fmradio.BuildConfig;
import com.vlad805.fmradio.C;
import com.vlad805.fmradio.Storage;
import com.vlad805.fmradio.Utils;
import com.vlad805.fmradio.service.fm.DatagramServer;
import com.vlad805.fmradio.service.fm.IFMController;
import com.vlad805.fmradio.service.fm.FMEventCallback;
import com.vlad805.fmradio.service.fm.IFMEventListener;
import com.vlad805.fmradio.service.fm.RadioStatePatch;
import com.vlad805.fmradio.service.fm.communication.Poll;
import com.vlad805.fmradio.service.fm.communication.Request;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class AbstractQualcommNativeController implements IFMController, IFMEventListener {
    private static final int CLIENT_PORT = 2112;
    private static final int SERVER_PORT = 2113;

    public interface Callback<T> {
        void onResult(T result);

        default void onError(final Error e) {
        }
    }

    protected static final class RootAccessDeniedError extends Error {
        RootAccessDeniedError(final String message) {
            super(message);
        }
    }

    protected final Context context;

    private DatagramServer mServer;
    private FMEventCallback mEventCallback;
    private final Poll mCommandPoll;

    protected AbstractQualcommNativeController(final Context context) {
        this.context = context;
        mCommandPoll = new Poll(CLIENT_PORT);
    }

    @SuppressLint("SdCardPath")
    public final String getAppRootPath() {
        return "/data/data/" + BuildConfig.APPLICATION_ID + "/files/";
    }

    public final String getAppRootPath(final String path) {
        return getAppRootPath() + path;
    }

    @Override
    public void setEventListener(final FMEventCallback callback) {
        mEventCallback = callback;
    }

    public boolean isInstalled() {
        return isNativeBinaryInstalled();
    }

    public boolean isObsolete() {
        return isNativeBinaryObsolete();
    }

    protected void installImpl(final Callback<Void> callback) {
        installNativeBinary(callback);
    }

    public final void install() {
        fireEvent(C.Event.INSTALLING);
        installImpl(new Callback<>() {
            @Override
            public void onResult(final Void result) {
                fireEvent(C.Event.INSTALLED);
            }

            @Override
            public void onError(final Error error) {
                Log.e("RFM-QCOM", "Failed to install native binary", error);
                fireEvent(C.Event.LAUNCH_FAILED);
            }
        });
    }

    protected abstract void launchImpl(final Callback<Void> callback);

    public final void launch() {
        fireEvent(C.Event.LAUNCHING);
        launchImpl(new Callback<>() {
            @Override
            public void onResult(final Void result) {
                fireEvent(C.Event.LAUNCHED);
            }

            @Override
            public void onError(final Error e) {
                Log.e("RFM-QCOM", "Failed to launch native tuner", e);
                fireEvent(e instanceof RootAccessDeniedError
                        ? C.Event.ROOT_ACCESS_DENIED
                        : C.Event.LAUNCH_FAILED);
            }
        });
    }

    protected void applyPreferenceImpl(final String key, final String value) {
        switch (key) {
            case C.PrefKey.TUNER_SPACING:
                sendCommand(new Request("set_spacing " + value));
                break;
            case C.PrefKey.TUNER_REGION:
                sendCommand(new Request("set_region " + value));
                break;
            case C.PrefKey.TUNER_STEREO:
                sendCommand(new Request("set_stereo " + value));
                break;
            case C.PrefKey.TUNER_SOFT_MUTE:
                sendCommand(new Request("set_soft_mute " + value));
                break;
            case C.PrefKey.TUNER_ANTENNA:
                onApplyAntennaPreference(value);
                break;
            case C.PrefKey.TUNER_POWER_MODE:
                sendCommand(new Request("power_mode " + value));
                break;
            case C.PrefKey.RDS_AUTO_AF:
                sendCommand(new Request("auto_af " + value));
                break;
        }
    }

    public final void applyPreference(final String key, final String value) {
        applyPreferenceImpl(key, value);
    }

    public final void prepareBinary() {
        fireEvent(C.Event.PREPARING);
        final File binary = new File(getBinaryPath());
        if (binary.isFile() && !isObsolete()) {
            if (ensureNativeBinaryExecutable(binary)) {
                fireEvent(C.Event.INSTALLED);
            } else {
                Log.e("RFM-QCOM", "Failed to restore native binary permissions: " + binary);
                fireEvent(C.Event.LAUNCH_FAILED);
            }
            return;
        }

        install();
    }

    protected void killImpl(final Callback<Void> callback) {
        if (!mCommandPoll.isEnabled()) {
            finishKill(callback);
            return;
        }

        disableImpl(result -> finishKill(callback));
    }

    private void finishKill(final Callback<Void> callback) {
        closeServerListener();
        killRunningBinary();
        callback.onResult(null);
    }

    public final void kill() {
        killImpl(result -> {
            fireEvent(C.Event.DISABLED);
            fireEvent(C.Event.KILLED);
        });
    }

    protected void enableImpl(final Callback<Void> callback) {
        sendCommand(new Request("enable", 5000).onResponse(result -> callback.onResult(null)));
    }

    protected boolean shouldApplyStartupPreferences() {
        return true;
    }

    public final void enable() {
        fireEvent(C.Event.ENABLING);
        enableImpl(new Callback<>() {
            @Override
            public void onResult(final Void result) {
                maybeApplyStartupPreferences();
                fireEvent(C.Event.ENABLED);
            }

            @Override
            public void onError(final Error error) {
                fireError(error.getMessage());
                fireEvent(C.Event.DISABLED);
            }
        });
    }

    private void maybeApplyStartupPreferences() {
        if (!shouldApplyStartupPreferences()) {
            return;
        }

        setupTunerByPreferences(getStartupPreferenceKeys());
    }

    protected String[] getStartupPreferenceKeys() {
        return new String[]{
                C.PrefKey.TUNER_REGION,
                C.PrefKey.TUNER_SPACING,
                C.PrefKey.TUNER_STEREO,
                C.PrefKey.TUNER_SOFT_MUTE,
                C.PrefKey.TUNER_ANTENNA,
                C.PrefKey.RDS_AUTO_AF,
        };
    }

    public void setupTunerByPreferences(final String[] changed) {
        for (final String key : changed) {
            String value = null;
            switch (key) {
                case C.PrefKey.TUNER_REGION: {
                    final int band = Storage.getPrefInt(context, key, C.PrefDefaultValue.TUNER_REGION);
                    value = String.valueOf(band);
                    break;
                }
                case C.PrefKey.TUNER_STEREO: {
                    final boolean stereo = Storage.getPrefBoolean(context, key, C.PrefDefaultValue.TUNER_STEREO);
                    value = stereo ? "1" : "0";
                    break;
                }
                case C.PrefKey.TUNER_SOFT_MUTE: {
                    final boolean enabled = Storage.getPrefBoolean(context, key, C.PrefDefaultValue.TUNER_SOFT_MUTE);
                    value = enabled ? "1" : "0";
                    break;
                }
                case C.PrefKey.TUNER_SPACING: {
                    final int spacing = Storage.getPrefInt(context, key, C.PrefDefaultValue.TUNER_SPACING);
                    applyPreference(key, String.valueOf(spacing));
                    final boolean stereo = Storage.getPrefBoolean(context, C.PrefKey.TUNER_STEREO, C.PrefDefaultValue.TUNER_STEREO);
                    applyPreference(C.PrefKey.TUNER_STEREO, stereo ? "1" : "0");
                    break;
                }
                case C.PrefKey.TUNER_ANTENNA: {
                    final int region = Storage.getPrefInt(context, key, C.PrefDefaultValue.TUNER_ANTENNA);
                    value = String.valueOf(region);
                    break;
                }
                case C.PrefKey.TUNER_POWER_MODE: {
                    final boolean isLowPower = Storage.getPrefBoolean(context, key, C.PrefDefaultValue.TUNER_POWER_MODE);
                    value = isLowPower ? "low" : "normal";
                    break;
                }
                case C.PrefKey.RDS_AUTO_AF: {
                    final boolean enabled = Storage.getPrefBoolean(context, key, C.PrefDefaultValue.RDS_AUTO_AF);
                    value = enabled ? "1" : "0";
                    break;
                }
            }

            if (value != null) {
                applyPreference(key, value);
            }
        }
    }

    protected void disableImpl(final Callback<Void> callback) {
        sendCommand(new Request("disable", 5000).onResponse(result -> callback.onResult(null)));
        mCommandPoll.toggle(false);
    }

    public final void disable() {
        fireEvent(C.Event.DISABLING);
        disableImpl(result -> fireEvent(C.Event.DISABLED));
    }

    protected abstract void setFrequencyImpl(final int kHz, final Callback<Integer> callback);

    public final void setFrequency(final int kHz) {
        setFrequencyImpl(kHz, result -> {
            final Bundle bundle = new Bundle();
            bundle.putInt(C.Key.FREQUENCY, kHz);
            fireEvent(C.Event.FREQUENCY_SET, bundle);
        });
    }

    protected void jumpImpl(final int direction, final Callback<Integer> callback) {
        sendCommand(new Request("jump " + direction, 1500).onResponse(data -> callback.onResult(Utils.parseInt(data))));
    }

    public final void jump(final int direction) {
        jumpImpl(direction, result -> {
            if (result < 0) {
                fireError("Error while jumping");
                return;
            }
            fireFrequencyEvent(C.Event.JUMP_COMPLETE, result);
        });
    }

    protected void hwSeekImpl(final int direction) {
        sendCommand(new Request("seekhw " + direction, 4000).onResponse(data -> {
            if (data == null || !data.startsWith("ok")) {
                fireError("Error while hwSeek: " + data);
            }
        }));
    }

    public void hwSeek(final int direction) {
        hwSeekImpl(direction);
    }

    protected void hwSearchImpl() {
        sendCommand(new Request("searchhw", 60000));
    }

    public void hwSearch() {
        hwSearchImpl();
    }

    protected void cancelHwSearchImpl() {
        sendCommand(new Request("search_cancel"));
    }

    public void cancelHwSearch() {
        cancelHwSearchImpl();
    }

    protected void setPowerModeImpl(final String mode) {
        sendCommand(new Request("power_mode " + mode));
    }

    public void setPowerMode(final String mode) {
        setPowerModeImpl(mode);
    }

    protected void fireEvent(final String event, final Bundle bundle) {
        Utils.sendAppBroadcast(context, new Intent(event).putExtras(bundle));
    }

    protected void fireEvent(final String event) {
        Utils.sendAppBroadcast(context, new Intent(event));
    }

    protected void fireError(final String message) {
        final Bundle bundle = new Bundle();
        bundle.putString(Intent.EXTRA_TEXT, message);
        fireEvent(C.Event.ERROR_OCCURRED, bundle);
    }

    private void fireFrequencyEvent(final String event, final int frequency) {
        final Bundle bundle = new Bundle();
        if (frequency > 0) {
            bundle.putInt(C.Key.FREQUENCY, frequency);
        }
        fireEvent(event, bundle);
    }

    protected abstract String getBinaryName();

    protected abstract String getBinaryVersionKey();

    protected final String getBinaryPath() {
        return getAppRootPath(getBinaryName());
    }

    protected void onApplyAntennaPreference(final String value) {
        sendCommand(new Request("set_antenna " + value));
    }

    protected final void toggleCommandPoll(final boolean enabled) {
        mCommandPoll.toggle(enabled);
    }

    protected final void sendCommand(final Request request) {
        mCommandPoll.send(request);
    }

    protected final void closeServerListener() {
        if (mServer != null) {
            mServer.closeServer();
            mServer = null;
        }
    }

    protected final boolean startServerListener() {
        try {
            closeServerListener();
            mServer = new DatagramServer(SERVER_PORT);
            mServer.setCallback(new FMEventCallback() {
                @Override
                public void onEvent(final String event) {
                    onServerEvent(event);
                    if (mEventCallback != null) {
                        mEventCallback.onEvent(event);
                    }
                }

                @Override
                public void onStatePatch(final RadioStatePatch patch) {
                    onServerStatePatch(patch);
                    if (mEventCallback != null) {
                        mEventCallback.onStatePatch(patch);
                    }
                }

                @Override
                public void onSearchDone(final int[] stations) {
                    onServerSearchDone(stations);
                    if (mEventCallback != null) {
                        mEventCallback.onSearchDone(stations);
                    }
                }
            });
            mServer.start();
            return true;
        } catch (final IOException e) {
            Log.e("RFM-QCOM", "Failed to start native event listener", e);
            return false;
        }
    }

    protected void onServerEvent(final String event) {
    }

    protected void onServerStatePatch(final RadioStatePatch patch) {
    }

    protected void onServerSearchDone(final int[] stations) {
    }

    protected final boolean isNativeBinaryInstalled() {
        final File binary = new File(getBinaryPath());
        return binary.isFile() && binary.canExecute();
    }

    protected final boolean isNativeBinaryObsolete() {
        final int binaryVersion = Storage.getInstance(context).getInt(getBinaryVersionKey(), 0);
        return BuildConfig.DEBUG || binaryVersion < BuildConfig.VERSION_CODE;
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    protected final void installNativeBinary(final Callback<Void> callback) {
        final File dir = new File(getAppRootPath());
        if (!dir.exists()) {
            dir.mkdirs();
        }

        try {
            if (!copyBinary()) {
                callback.onError(new Error("Error while copy binary"));
                return;
            }
        } catch (final FileNotFoundException e) {
            Utils.runAsRoot("killall " + getBinaryName());
            try {
                if (!copyBinary()) {
                    callback.onError(new Error("Error while copy binary after kill busy binary"));
                    return;
                }
            } catch (final FileNotFoundException e2) {
                callback.onError(new Error("Error while copy binary after kill busy binary"));
                return;
            }
        }

        if (!ensureNativeBinaryExecutable(new File(getBinaryPath()))) {
            callback.onError(new Error("Failed to make native binary executable"));
            return;
        }

        Storage.getInstance(context).put(getBinaryVersionKey(), BuildConfig.VERSION_CODE);
        callback.onResult(null);
    }

    private boolean ensureNativeBinaryExecutable(final File binary) {
        try {
            //noinspection OctalInteger
            Os.chmod(binary.getAbsolutePath(), 0755);
            return binary.isFile() && binary.canExecute();
        } catch (final ErrnoException | SecurityException e) {
            Log.e("RFM-QCOM", "Failed to chmod native binary: " + binary, e);
            return false;
        }
    }

    protected final void killRunningBinary() {
        Utils.runAsRoot(String.format("killall %1$s 1>/dev/null 2>/dev/null &", getBinaryName()));
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    private boolean copyBinary() throws FileNotFoundException {
        return copyAsset(getBinaryName(), getBinaryPath());
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    private boolean copyAsset(final String fromAssetPath, final String toPath) throws FileNotFoundException {
        try {
            final InputStream in = context.getAssets().open(fromAssetPath);
            final File targetPath = new File(toPath);

            if (targetPath.exists()) {
                targetPath.delete();
            }

            targetPath.createNewFile();
            final OutputStream out = new FileOutputStream(toPath);

            final byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }

            in.close();
            out.flush();
            out.close();
            return true;
        } catch (final IOException e) {
            if (e instanceof FileNotFoundException) {
                throw (FileNotFoundException) e;
            }
            e.printStackTrace();
            return false;
        }
    }
}
