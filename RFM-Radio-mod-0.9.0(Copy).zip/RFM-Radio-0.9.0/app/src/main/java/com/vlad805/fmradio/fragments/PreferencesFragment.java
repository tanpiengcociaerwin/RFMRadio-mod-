package com.vlad805.fmradio.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.SparseArray;
import android.widget.Toast;
import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.preference.*;
import com.vlad805.fmradio.*;
import com.vlad805.fmradio.R;
import com.vlad805.fmradio.helper.ProgressDialog;
import com.vlad805.fmradio.preferences.Vars;
import net.grandcentrix.tray.AppPreferences;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static com.vlad805.fmradio.Utils.*;

/**
 * vlad805 (c) 2020
 */
public class PreferencesFragment extends PreferenceFragmentCompat implements Preference.OnPreferenceClickListener {
	/** Permission request used when enabling continuous FM capture. */
	private static final int REQUEST_RECORD_AUDIO_FOR_PRE_ROLL = 1001;

	private ProgressDialog mProgress;
	private AppPreferences mPreferences;

	@Override
	public void onCreatePreferences(final Bundle savedInstanceState, final String rootKey) {
		final Context context = requireContext();
		mPreferences = new AppPreferences(context);

		final PreferenceScreen screen = getPreferenceManager().createPreferenceScreen(context);

		makeTunerCategoryPreferences(context, screen);
		makeRdsCategoryPreferences(context, screen);
		makeRecordingCategoryPreferences(context, screen);
		makeApplicationCategoryPreferences(context, screen);
		makeNotificationsCategoryPreferences(context, screen);
		makeInfoCategoryPreferences(context, screen);

		setPreferenceScreen(screen);


	}

	private PreferenceCategory makeCategory(final Context context, final @StringRes int title, final String key) {
		final PreferenceCategory category = new PreferenceCategory(context);
		category.setKey(key);
		category.setTitle(title);
		return category;
	}

	private void populatePreference(final Preference pref, final String key, final @StringRes int title, final @DrawableRes int icon) {
		pref.setKey(key);
		pref.setTitle(title);

		if (pref instanceof DialogPreference) {
			((DialogPreference) pref).setDialogTitle(title);
		}

		if (icon != 0) {
			pref.setIcon(icon);
		}
	}

	private void makeTunerCategoryPreferences(final Context context, final PreferenceScreen screen) {
		final PreferenceCategory category = makeCategory(context, R.string.pref_header_tuner, "tuner");
		screen.addPreference(category);

		final ListPreference region = new ListPreference(context);
		populatePreference(region, C.PrefKey.TUNER_REGION, R.string.pref_tuner_region, R.drawable.ic_band);
		region.setDefaultValue(String.valueOf(C.PrefDefaultValue.TUNER_REGION));
		setListProviderAndEntries(region, Vars.sTunerRegions);
		region.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.TUNER_REGION, Utils.parseInt((String) newValue));
			return true;
		});
		category.addPreference(region);


		final ListPreference spacing = new ListPreference(context);
		populatePreference(spacing, C.PrefKey.TUNER_SPACING, R.string.pref_tuner_spacing, R.drawable.ic_step_freq);
		spacing.setDefaultValue(String.valueOf(C.PrefDefaultValue.TUNER_SPACING));
		setListProviderAndEntries(spacing, Vars.sTunerSpacing);
		spacing.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.TUNER_SPACING, Utils.parseInt((String) newValue));
			return true;
		});
		category.addPreference(spacing);


		final SwitchPreference stereo = new SwitchPreference(context);
		populatePreference(stereo, C.PrefKey.TUNER_STEREO, R.string.pref_tuner_stereo, 0);
		stereo.setDefaultValue(C.PrefDefaultValue.TUNER_STEREO);
		stereo.setSummaryOn(R.string.pref_tuner_stereo_on);
		stereo.setSummaryOff(R.string.pref_tuner_stereo_off);
		stereo.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.TUNER_STEREO, (boolean) newValue);
			return true;
		});
		category.addPreference(stereo);

		final SwitchPreference softMute = new SwitchPreference(context);
		populatePreference(softMute, C.PrefKey.TUNER_SOFT_MUTE, R.string.pref_tuner_soft_mute, 0);
		softMute.setDefaultValue(C.PrefDefaultValue.TUNER_SOFT_MUTE);
		softMute.setSummaryOn(R.string.pref_tuner_soft_mute_on);
		softMute.setSummaryOff(R.string.pref_tuner_soft_mute_off);
		softMute.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.TUNER_SOFT_MUTE, (boolean) newValue);
			return true;
		});
		category.addPreference(softMute);


		final EditTextPreference antenna = new EditTextPreference(context);
		populatePreference(antenna, C.PrefKey.TUNER_ANTENNA, R.string.pref_tuner_antenna, R.drawable.ic_antenna);
		antenna.setDefaultValue(String.valueOf(C.PrefDefaultValue.TUNER_ANTENNA));
		setEditTextMessageAndProvider(antenna, InputType.TYPE_CLASS_NUMBER);
		antenna.setDialogMessage(R.string.pref_tuner_antenna_message);
		antenna.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.TUNER_ANTENNA, Utils.parseInt((String) newValue));
			return true;
		});
		category.addPreference(antenna);


		final SwitchPreference power = new SwitchPreference(context);
		populatePreference(power, C.PrefKey.TUNER_POWER_MODE, R.string.pref_tuner_power_mode, R.drawable.ic_power);
		power.setDefaultValue(C.PrefDefaultValue.TUNER_POWER_MODE);
		power.setSummaryOn(R.string.pref_tuner_power_mode_low);
		power.setSummaryOff(R.string.pref_tuner_power_mode_normal);
		power.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.TUNER_POWER_MODE, (boolean) newValue);
			return true;
		});
		category.addPreference(power);
	}

	private void makeRdsCategoryPreferences(final Context context, final PreferenceScreen screen) {
		final PreferenceCategory category = makeCategory(context, R.string.pref_header_rds, "rds");
		screen.addPreference(category);

		final Preference description = new Preference(context);
		description.setKey("tuner_rds_description");
		description.setSummary(R.string.pref_tuner_rds_description);
		description.setEnabled(false);
		category.addPreference(description);

		final SwitchPreference autoAf = new SwitchPreference(context);
		populatePreference(autoAf, C.PrefKey.RDS_AUTO_AF, R.string.pref_tuner_rds_auto_af, R.drawable.ic_rds);
		autoAf.setDefaultValue(C.PrefDefaultValue.RDS_AUTO_AF);
		autoAf.setSummaryOn(R.string.pref_tuner_rds_auto_afenabled);
		autoAf.setSummaryOff(R.string.pref_tuner_rds_auto_af_disabled);
		autoAf.setOnPreferenceChangeListener((preference, newValue) -> {
			mPreferences.put(C.PrefKey.RDS_AUTO_AF, (boolean) newValue);
			return true;
		});
		category.addPreference(autoAf);
	}

	private void makeRecordingCategoryPreferences(final Context context, final PreferenceScreen screen) {
		final PreferenceCategory category = makeCategory(context, R.string.pref_header_recording, "recording");
		screen.addPreference(category);

		final EditTextPreference directory = new EditTextPreference(context);
		populatePreference(directory, C.PrefKey.RECORDING_DIRECTORY, R.string.pref_recording_path_title, R.drawable.ic_directory);
		directory.setDefaultValue(getString(R.string.pref_recording_path_value));
		directory.setDialogMessage(R.string.pref_recording_path_name_description);
		setEditTextMessageAndProvider(directory, InputType.TYPE_CLASS_TEXT);
		directory.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.RECORDING_DIRECTORY, (String) newValue);
			return true;
		});
		category.addPreference(directory);

		final EditTextPreference filename = new EditTextPreference(context);
		populatePreference(filename, C.PrefKey.RECORDING_FILENAME, R.string.pref_recording_name_title, R.drawable.ic_file_music);
		filename.setDefaultValue(getString(R.string.pref_recording_name_value));
		filename.setDialogMessage(R.string.pref_recording_path_name_description);
		setEditTextMessageAndProvider(filename, InputType.TYPE_CLASS_TEXT);
		filename.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.RECORDING_FILENAME, (String) newValue);
			return true;
		});
		category.addPreference(filename);

		final ListPreference format = new ListPreference(context);
		populatePreference(format, C.PrefKey.RECORDING_FORMAT, R.string.pref_recording_format_title, R.drawable.ic_recording_format);
		format.setDefaultValue(String.valueOf(C.PrefDefaultValue.RECORDING_FORMAT));
		setListProviderAndEntries(
				format,
				new int[]{C.RecordFormat.WAV, C.RecordFormat.MP3_128, C.RecordFormat.MP3_192},
				new String[]{
						getString(R.string.pref_recording_format_wav),
						getString(R.string.pref_recording_format_mp3_128),
						getString(R.string.pref_recording_format_mp3_192)
				}
		);
		format.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.RECORDING_FORMAT, Utils.parseInt((String) newValue));
			return true;
		});
		category.addPreference(format);

		final SwitchPreferenceCompat savePast = new SwitchPreferenceCompat(context);
		populatePreference(savePast, C.PrefKey.RECORDING_SAVE_PAST, R.string.pref_recording_save_past, R.drawable.ic_record_on);
		savePast.setDefaultValue(C.PrefDefaultValue.RECORDING_SAVE_PAST);
		savePast.setSummary(R.string.pref_recording_save_past_summary);
		savePast.setOnPreferenceChangeListener((preference, newValue) -> {
			if (!(boolean) newValue) {
				mPreferences.put(C.PrefKey.RECORDING_SAVE_PAST, false);
				return true;
			}

			new AlertDialog.Builder(requireContext())
					.setTitle(R.string.pref_recording_save_past_warning_title)
					.setMessage(R.string.pref_recording_save_past_warning_message)
					.setNegativeButton(android.R.string.cancel, null)
					.setPositiveButton(android.R.string.ok, (dialog, which) -> enablePreRoll(savePast))
					.show();
			return false;
		});
		category.addPreference(savePast);

		final SwitchPreferenceCompat notify = new SwitchPreferenceCompat(context);
		populatePreference(notify, C.PrefKey.RECORDING_SHOW_NOTIFY, R.string.pref_recording_show_notify, R.drawable.ic_info);
		notify.setDefaultValue(C.PrefDefaultValue.RECORDING_SHOW_NOTIFY);
		notify.setSummary(R.string.pref_recording_show_notify_summary);
		notify.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.RECORDING_SHOW_NOTIFY, (boolean) newValue);
			return true;
		});
		category.addPreference(notify);
	}

	/** Requests microphone access before enabling persistent pre-roll capture. */
	private void enablePreRoll(final SwitchPreferenceCompat preference) {
		if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
				== PackageManager.PERMISSION_GRANTED) {
			setPreRollEnabled(preference);
			return;
		}

		requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_FOR_PRE_ROLL);
	}

	/** Persists the enabled preference and synchronizes the visible switch. */
	private void setPreRollEnabled(final SwitchPreferenceCompat preference) {
		mPreferences.put(C.PrefKey.RECORDING_SAVE_PAST, true);
		preference.setChecked(true);
	}

	@Override
	public void onRequestPermissionsResult(final int requestCode, final String[] permissions, final int[] grantResults) {
		if (requestCode == REQUEST_RECORD_AUDIO_FOR_PRE_ROLL) {
			final SwitchPreferenceCompat preference = findPreference(C.PrefKey.RECORDING_SAVE_PAST);
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
					&& preference != null) {
				setPreRollEnabled(preference);
			} else {
				Toast.makeText(requireContext(), R.string.record_permissions_required, Toast.LENGTH_LONG).show();
			}
			return;
		}

		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
	}

	private void makeApplicationCategoryPreferences(final Context context, final PreferenceScreen screen) {
		final PreferenceCategory category = makeCategory(context, R.string.pref_header_app, "app");
		screen.addPreference(category);

		final SwitchPreferenceCompat autostart = new SwitchPreferenceCompat(context);
		populatePreference(autostart, C.PrefKey.APP_AUTO_STARTUP, R.string.pref_app_auto_startup, R.drawable.ic_autostart);
		autostart.setDefaultValue(C.PrefDefaultValue.APP_AUTO_STARTUP);
		autostart.setSummaryOn(R.string.pref_app_auto_startup_enabled);
		autostart.setSummaryOff(R.string.pref_auto_startup_disabled);
		autostart.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.APP_AUTO_STARTUP, (boolean) newValue);
			return true;
		});
		category.addPreference(autostart);
	}

	private void makeNotificationsCategoryPreferences(final Context context, final PreferenceScreen screen) {
		final PreferenceCategory category = makeCategory(context, R.string.pref_header_notifications, "notifications");
		screen.addPreference(category);

		final SwitchPreferenceCompat showPs = new SwitchPreferenceCompat(context);
		populatePreference(showPs, C.PrefKey.NOTIFICATION_SHOW_RDS, R.string.pref_notification_show_ps, R.drawable.ic_ps_name);
		showPs.setDefaultValue(C.PrefDefaultValue.NOTIFICATION_SHOW_RDS);
		showPs.setSummaryOn(R.string.pref_notification_show_ps_enabled);
		showPs.setSummaryOff(R.string.pref_notification_show_ps_disabled);
		showPs.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.NOTIFICATION_SHOW_RDS, (boolean) newValue);
			return true;
		});
		category.addPreference(showPs);


		final SwitchPreferenceCompat seekByFav = new SwitchPreferenceCompat(context);
		populatePreference(seekByFav, C.PrefKey.NOTIFICATION_SEEK_BY_FAVORITES, R.string.pref_notification_seek_by_favorites, R.drawable.ic_seek_arrows);
		seekByFav.setDefaultValue(C.PrefDefaultValue.NOTIFICATION_SEEK_BY_FAVORITES);
		seekByFav.setSummaryOn(R.string.pref_notification_seek_by_favorites_enabled);
		seekByFav.setSummaryOff(R.string.pref_notification_seek_by_favorites_disabled);
		seekByFav.setOnPreferenceChangeListener((preference, newValue) -> {
			Storage.getInstance(context).put(C.PrefKey.NOTIFICATION_SEEK_BY_FAVORITES, (boolean) newValue);
			return true;
		});
		category.addPreference(seekByFav);
	}

	private void makeInfoCategoryPreferences(final Context context, final PreferenceScreen screen) {
		final PreferenceCategory category = makeCategory(context, R.string.pref_header_info, "info");
		screen.addPreference(category);


		final Preference version = new Preference(context);
		populatePreference(version, "pref_info_version", R.string.pref_info_version_title, 0);
		version.setSummary(String.format(Locale.ENGLISH, "v%s (build %d / %s)", BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE, BuildConfig.BUILD_TYPE));
		version.setOnPreferenceClickListener(this);
		category.addPreference(version);

	}

	private void setEditTextMessageAndProvider(final EditTextPreference preference, final int type) {
		preference.setSummaryProvider((Preference.SummaryProvider<EditTextPreference>) EditTextPreference::getText);
		preference.setOnBindEditTextListener(editText -> editText.setInputType(type));
	}

	private void setListProviderAndEntries(final ListPreference lp, final SparseArray<String> entries) {
		final List<String> keys = new ArrayList<>();
		final List<String> values = new ArrayList<>();

		for (int i = 0; i < entries.size(); ++i) {
			final int k = entries.keyAt(i);

			keys.add(String.valueOf(k));
			values.add(entries.get(k));
		}

		lp.setSummaryProvider((Preference.SummaryProvider<ListPreference>) s -> {
			int id = entries.indexOfKey(Utils.parseInt(s.getValue()));
			if (id < 0) {
				id = 0;
			}
			return entries.valueAt(id);
		});
		lp.setEntries(values.toArray(new String[0]));
		lp.setEntryValues(keys.toArray(new String[0]));
	}

	/**
	 * Configures ordered list entries whose persisted integer values need not match display order.
	 *
	 * @param preference List preference to configure
	 * @param keys Stable integer values persisted for each entry
	 * @param values User-visible entry labels in display order
	 */
	private void setListProviderAndEntries(
			final ListPreference preference,
			final int[] keys,
			final String[] values
	) {
		final String[] entryValues = new String[keys.length];
		for (int i = 0; i < keys.length; i++) {
			entryValues[i] = String.valueOf(keys[i]);
		}

		preference.setSummaryProvider((Preference.SummaryProvider<ListPreference>) selected -> {
			final String value = selected.getValue();
			for (int i = 0; i < entryValues.length; i++) {
				if (entryValues[i].equals(value)) {
					return values[i];
				}
			}
			return values[0];
		});
		preference.setEntries(values);
		preference.setEntryValues(entryValues);
	}

	@Override
	public boolean onPreferenceClick(final Preference preference) {
		final Context context = requireContext();

		switch (preference.getKey()) {
			case "pref_info_version": {
				checkVersion();
				break;
			}

		}
		return false;
	}

	private void warnApplyPreferenceOnlyAfterRestartApp() {
		Toast.makeText(getContext(), R.string.pref_warning_applying_only_after_restart, Toast.LENGTH_LONG).show();
	}

	private void checkVersion() {
		final Context ctx = getContext();
		mProgress = ProgressDialog.create(ctx).text(R.string.pref_version_check_progress).show();
		fetch("https://rfm.velu.ga/app_version.json", new Utils.FetchCallback() {
			@Override
			public void onSuccess(final JSONObject json) {
				mProgress.hide();

				final JSONObject latest = json.optJSONObject("latest");

				if (latest == null) {
					Toast.makeText(ctx, "err", Toast.LENGTH_SHORT).show();
					return;
				}

				final boolean isFresh = latest.optInt("build") <= BuildConfig.VERSION_CODE;

				String title;
				String content;

				if (isFresh) {
					title = PreferencesFragment.this.getString(R.string.pref_version_check_fresh_title);
					content = PreferencesFragment.this.getString(R.string.pref_version_check_fresh_content);
				} else {
					title = PreferencesFragment.this.getString(R.string.pref_version_check_need_update_title);
					content = PreferencesFragment.this.getString(
							R.string.pref_version_check_need_update_content,
							latest.optString("version"),
							latest.optInt("build"),
							BuildConfig.VERSION_NAME,
							BuildConfig.VERSION_CODE,
							latest.optString("changelog", "< not specified >")
					);
				}

				final AlertDialog.Builder ab = new AlertDialog.Builder(Objects.requireNonNull(ctx));
				ab.setTitle(title).setMessage(content);

				if (!isFresh) {
					ab.setPositiveButton(R.string.pref_version_check_need_update_ok, (dialog, which) -> {
						final Intent intent = new Intent(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(latest.optString("url")));
						PreferencesFragment.this.startActivity(intent);
					});
				}

				ab.setNegativeButton(android.R.string.cancel, (dialog, which) -> dialog.cancel());

				ab.create().show();
			}

			@Override
			public void onError(final Throwable exception) {
				mProgress.hide();

				Toast.makeText(getContext(), getString(R.string.pref_version_check_error, exception.getMessage()), Toast.LENGTH_LONG).show();
			}
		});
	}
}
