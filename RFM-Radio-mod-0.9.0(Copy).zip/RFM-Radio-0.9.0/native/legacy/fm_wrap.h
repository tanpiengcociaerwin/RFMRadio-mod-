#include "fmcommon.h"

#ifndef FMBIN_FM_WRAP_H
#define FMBIN_FM_WRAP_H

#ifdef __cplusplus
extern "C" {
#endif

fm_cmd_status_t fm_command_open();
fm_cmd_status_t fm_command_prepare(fm_config_data* config_ptr);
fm_cmd_status_t fm_command_setup_receiver(fm_config_data* ptr);
fm_cmd_status_t fm_command_setup_rds(rds_system_t system);
fm_cmd_status_t fm_command_disable();

fm_cmd_status_t fm_command_tune_frequency(uint32 frequency);
fm_cmd_status_t fm_command_tune_frequency_by_delta(signed short direction);
uint32 fm_command_get_tuned_frequency();
bool fm_command_publish_rmssi();
bool fm_command_start_seek(int8 direction, uint8 dwell_period);
bool fm_command_start_scan();
bool fm_command_cancel_scan();
bool fm_command_search_busy();
void fm_command_abandon_search();

fm_cmd_status_t fm_command_set_mute_mode(mute_t mode);
fm_cmd_status_t fm_command_set_stereo_mode(stereo_t is_stereo);

/*
fm_cmd_status_t fm_receiver_set_rds_options(fm_rds_options options);
fm_cmd_status_t fm_command_set_rds_group_proc(uint32 rdsgroup);
fm_cmd_status_t fm_command_set_power_mode(power_mode_t mode);
fm_cmd_status_t fm_command_set_signal_threshold(uint8 threshold);
fm_cmd_status_t fm_receiver_search_stations(fm_search_stations options);
fm_cmd_status_t fm_receiver_search_rds_stations(fm_search_rds_stations options);
fm_cmd_status_t fm_receiver_search_station_list(fm_search_list_stations options);
fm_cmd_status_t fm_receiver_cancel_search();
 */

#ifdef __cplusplus
}
#endif

#endif //FMBIN_FM_WRAP_H
