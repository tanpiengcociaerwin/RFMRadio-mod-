package com.vlad805.fmradio.controller;

import android.content.Context;
import android.os.Environment;
import com.vlad805.fmradio.Storage;
import com.vlad805.fmradio.helper.json.JSONFile;
import com.vlad805.fmradio.models.FavoriteFile;
import com.vlad805.fmradio.models.FavoriteStation;
import net.grandcentrix.tray.AppPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * vlad805 (c) 2020
 */
public class FavoriteController extends JSONFile<FavoriteFile> {
	private List<FavoriteStation> mList;
	private final AppPreferences mStorage;

	private static final String KEY_CURRENT_LIST = "favorites_list_current";
	private static final String KEY_JSON_ITEMS = "items";
	public static final String DEFAULT_NAME = "default";
	public static final int MAX_IMPORT_BYTES = 1024 * 1024;

	private static final String JSON_EXT = ".json";

	public FavoriteController(final Context context) {
		super(context);
		this.mStorage = Storage.getInstance(context);
		migrateLegacyFavorites();
	}

	/**
	 * Returns all lists
	 * @return Names of lists
	 */
	public List<String> getFavoriteLists() {
		final File dir = getFavoritesDirectory();
		final String[] files = dir.list();
		if (files == null) {
			return new ArrayList<>();
		}

		for (int i = 0; i < files.length; ++i) {
			files[i] = files[i].replace(JSON_EXT, "");
		}

		Arrays.sort(files);

		return Arrays.asList(files);
	}

	public int getStationsCountInList(final String name) {
		final File file = new File(getFavoritesDirectory(), name + JSON_EXT);
		if (!file.exists()) {
			return 0;
		}

		try (final FileInputStream input = new FileInputStream(file); final ByteArrayOutputStream output = new ByteArrayOutputStream()) {
			final byte[] buffer = new byte[8192];
			int read;
			while ((read = input.read(buffer)) != -1) {
				output.write(buffer, 0, read);
			}

			final JSONObject object = new JSONObject(output.toString());
			return object.getJSONArray(KEY_JSON_ITEMS).length();
		} catch (IOException | JSONException e) {
			return 0;
		}
	}

	/**
	 * Returns name of file of current favorite list
	 * @return filename without extension
	 */
	public String getCurrentFavoriteList() {
		return mStorage.getString(KEY_CURRENT_LIST, DEFAULT_NAME);
	}

	/**
	 * Change current favorite list by name
	 * @param name Name of favorite list
	 */
	public void setCurrentFavoriteList(final String name) throws FileNotFoundException {
		// app                     stat     name   .json
		// /storage/emulated/0/Android/data/com.vlad805.fmradio/files/favorites/default.json
		final File file = new File(getFavoritesDirectory(), name + JSON_EXT);
		if (!file.exists()) {
			throw new FileNotFoundException("setCurrentFavoriteList: not found list with name '" + name + "'; full path = " + file.getAbsolutePath());
		}

		mStorage.put(KEY_CURRENT_LIST, name);
		reload();
	}

	/**+
	 * Returns favorite stations in list of current list
	 * @return Stations in list
	 */
	public List<FavoriteStation> getStationsInCurrentList() {
		if (mList == null) {
			reload();
		}

		return mList;
	}

	/**
	 * Check name for validity
	 * @param name Name of list
	 * @return True if invalid
	 */
	public boolean isInvalidName(final String name) {
		return !name.matches("[A-Za-z0-9_-]+");
	}

	/**
	 * Check name for existing
	 * @param name Name of list
	 * @return True, if already exists
	 */
	public boolean isAlreadyExists(final String name) {
		return new File(getFavoritesDirectory(), name + JSON_EXT).exists();
	}

	/**
	 * Create new empty list
	 * @param name Name of list
	 * @return True, if created successfully
	 * @throws Error if name is invalid or list with same name already exists
	 */
	public boolean addList(final String name) {
		if (isInvalidName(name)) {
			throw new Error("Invalid name");
		}

		if (isAlreadyExists(name)) {
			throw new Error("List with this name already exists");
		}

		final File file = new File(getFavoritesDirectory(), name + JSON_EXT);

		try (final FileOutputStream stream = new FileOutputStream(file)) {
			stream.write("{\"items\":[]}".getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return true;
	}

	public boolean renameList(final String oldName, final String newName) {
		if (DEFAULT_NAME.equals(oldName)) {
			return false;
		}

		if (isInvalidName(newName)) {
			throw new Error("Invalid name");
		}

		if (oldName.equals(newName)) {
			return true;
		}

		if (isAlreadyExists(newName)) {
			throw new Error("List with this name already exists");
		}

		final File oldFile = new File(getFavoritesDirectory(), oldName + JSON_EXT);
		final File newFile = new File(getFavoritesDirectory(), newName + JSON_EXT);
		if (!oldFile.exists()) {
			throw new Error("List not found");
		}

		if (!oldFile.renameTo(newFile)) {
			throw new Error("Cannot rename list");
		}

		if (oldName.equals(getCurrentFavoriteList())) {
			mStorage.put(KEY_CURRENT_LIST, newName);
			reload();
		}

		return true;
	}

	public String importList(final String suggestedName, final InputStream inputStream) throws IOException {
		final String importedJson = readInputStream(inputStream);
		validateFavoriteListJson(importedJson);

		final String baseName = sanitizeImportedName(suggestedName);
		final String finalName = makeUniqueListName(baseName);
		final File file = new File(getFavoritesDirectory(), finalName + JSON_EXT);

		try (final FileOutputStream stream = new FileOutputStream(file)) {
			stream.write(importedJson.getBytes());
		}

		return finalName;
	}

	public void exportCurrentList(final OutputStream outputStream) throws IOException {
		try (final OutputStream output = outputStream) {
			output.write(readFile().getBytes());
		}
	}

	public void exportList(final String listName, final OutputStream outputStream) throws IOException {
		final File file = new File(getFavoritesDirectory(), listName + JSON_EXT);
		if (!file.exists()) {
			throw new FileNotFoundException("List not found: " + listName);
		}

		try (final FileInputStream inputStream = new FileInputStream(file); final OutputStream output = outputStream) {
			final byte[] buffer = new byte[8192];
			int read;
			while ((read = inputStream.read(buffer)) != -1) {
				output.write(buffer, 0, read);
			}
		}
	}

	public void exportAllLists(final OutputStream outputStream) throws IOException {
		exportLists(outputStream, getFavoriteLists());
	}

	public void exportLists(final OutputStream outputStream, final List<String> listNames) throws IOException {
		try (final ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream)) {
			for (final String listName : listNames) {
				final File file = new File(getFavoritesDirectory(), listName + JSON_EXT);
				if (!file.exists()) {
					continue;
				}

				zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
				try (final FileInputStream inputStream = new FileInputStream(file)) {
					final byte[] buffer = new byte[8192];
					int read;
					while ((read = inputStream.read(buffer)) != -1) {
						zipOutputStream.write(buffer, 0, read);
					}
				}
				zipOutputStream.closeEntry();
			}
			zipOutputStream.finish();
		}
	}

	/**
	 * Remove favorite list
	 * @param name Name of list to remove
	 * @return True, if successfully
	 */
	public boolean removeList(final String name) {
		if (name.equals(DEFAULT_NAME)) {
			return false;
		}

		final File file = new File(getFavoritesDirectory(), name + JSON_EXT);
		if (getCurrentFavoriteList().equals(name)) {
			try {
				setCurrentFavoriteList(DEFAULT_NAME);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		return file.delete();
	}

	/**
	 * Load and parse favorite list from file (current list)
	 */
	public void reload() {
		mList = read().getItems();
	}

	/**
	 * Save local list to file (current list)
	 */
	public void save() {
		write(new FavoriteFile(mList));
	}

	/**
	 * Name of current favorites list
	 * @return Filename with extension
	 */
	@Override
	public String getPath() {
		return "favorites" + File.separator + getCurrentFavoriteList() + JSON_EXT;
	}

	/**
	 * Read and parse file of list
	 * @return Struct
	 */
	@Override
	public FavoriteFile read() {
		try {
			final String str = readFile();
			final JSONObject obj = new JSONObject(str);
			final JSONArray items = obj.getJSONArray(KEY_JSON_ITEMS);
			final List<FavoriteStation> fs = new ArrayList<>();

			for (int i = 0; i < items.length(); ++i) {
				fs.add(new FavoriteStation(items.optJSONObject(i)));
			}

			return new FavoriteFile(fs);
		} catch (JSONException e) {
			return new FavoriteFile(new ArrayList<>());
		}
	}

	/**
	 * Write data to file
	 * @param data Fresh favorite list
	 */
	@Override
	public void write(final FavoriteFile data) {
		try {
			final List<JSONObject> list = new ArrayList<>();

			for (final FavoriteStation station : mList) {
				list.add(station.toJson());
			}

			final String str = new JSONObject().put(KEY_JSON_ITEMS, new JSONArray(list)).toString();

			writeFile(str);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void migrateLegacyFavorites() {
		final File newDir = getFavoritesDirectory();
		final String[] currentFiles = newDir.list();
		if (currentFiles != null && currentFiles.length > 0) {
			return;
		}

		final File legacyDir = new File(Environment.getExternalStorageDirectory(), "RFM/favorites");
		final File[] legacyFiles = legacyDir.listFiles((dir, name) -> name.endsWith(JSON_EXT));
		if (legacyFiles == null || legacyFiles.length == 0) {
			return;
		}

		for (final File legacyFile : legacyFiles) {
			final File targetFile = new File(newDir, legacyFile.getName());
			if (targetFile.exists()) {
				continue;
			}

			try (
					final FileInputStream input = new FileInputStream(legacyFile);
					final FileOutputStream output = new FileOutputStream(targetFile)
			) {
				final byte[] buffer = new byte[8192];
				int read;
				while ((read = input.read(buffer)) != -1) {
					output.write(buffer, 0, read);
				}
			} catch (IOException ignored) {
			}
		}
	}

	private File getFavoritesDirectory() {
		final File dir = new File(getBaseApplicationDirectory(), "favorites");
		if (!dir.exists() && !dir.mkdirs()) {
			throw new IllegalStateException("Cannot create favorites directory");
		}
		return dir;
	}

	private String readInputStream(final InputStream inputStream) throws IOException {
		try (final InputStream input = inputStream; final ByteArrayOutputStream output = new ByteArrayOutputStream()) {
			final byte[] buffer = new byte[8192];
			int read;
			while ((read = input.read(buffer)) != -1) {
				if (output.size() + read > MAX_IMPORT_BYTES) {
					throw new IOException("Favorites import file is too large");
				}
				output.write(buffer, 0, read);
			}
			return output.toString();
		}
	}

	private void validateFavoriteListJson(final String importedJson) throws IOException {
		try {
			final JSONObject object = new JSONObject(importedJson);
			final JSONArray items = object.getJSONArray(KEY_JSON_ITEMS);
			for (int i = 0; i < items.length(); ++i) {
				new FavoriteStation(items.getJSONObject(i));
			}
		} catch (JSONException e) {
			throw new IOException("Invalid favorites JSON", e);
		}
	}

	private String sanitizeImportedName(final String suggestedName) {
		String baseName = suggestedName;
		final int dotIndex = baseName.lastIndexOf('.');
		if (dotIndex > 0) {
			baseName = baseName.substring(0, dotIndex);
		}

		baseName = baseName.trim().replaceAll("[^A-Za-z0-9_-]+", "_");
		baseName = baseName.replaceAll("_+", "_");
		baseName = baseName.replaceAll("^_+|_+$", "");

		if (baseName.isEmpty()) {
			baseName = "imported";
		}

		return baseName.toLowerCase(Locale.ENGLISH);
	}

	private String makeUniqueListName(final String baseName) {
		if (!isAlreadyExists(baseName)) {
			return baseName;
		}

		int suffix = 1;
		while (isAlreadyExists(baseName + "_" + suffix)) {
			suffix++;
		}
		return baseName + "_" + suffix;
	}
}
