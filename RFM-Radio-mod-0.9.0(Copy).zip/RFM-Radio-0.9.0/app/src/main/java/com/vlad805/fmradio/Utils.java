package com.vlad805.fmradio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Locale;

/**
 * vlad805 (c) 2019
 */
public class Utils {
	private static final long SHELL_TIMEOUT_MS = 15_000L;
	private static final String[] ROOT_BINARY_PATHS = {
			"/system/bin/su",
			"/system/xbin/su",
			"/sbin/su",
			"/su/bin/su",
			"/vendor/bin/su",
			"/data/local/bin/su",
			"/data/local/xbin/su",
			"/data/local/su"
	};

	/**
	 * Checks for an available su binary without executing it or requesting root access.
	 */
	public static boolean isRootEnvironmentAvailable() {
		final String path = System.getenv("PATH");
		if (path != null) {
			for (final String directory : path.split(":")) {
				if (isExecutableFile(new File(directory, "su"))) {
					return true;
				}
			}
		}

		for (final String binaryPath : ROOT_BINARY_PATHS) {
			if (isExecutableFile(new File(binaryPath))) {
				return true;
			}
		}

		return false;
	}

	private static boolean isExecutableFile(final File file) {
		return file.isFile() && file.canExecute();
	}

	/**
	 *
	 * https://github.com/termux/termux-app/blob/master/app/src/main/java/com/termux/app/TermuxInstaller.java#L179
	 */
	public static String determineArch() {
		for (final String androidArch : Build.SUPPORTED_ABIS) {
			switch (androidArch) {
				case "arm64-v8a": {
					return "aarch64";
				}

				case "armeabi-v7a": {
					return "armv7a";
				}
			}
		}
		throw new RuntimeException("Unable to determine arch from Build.SUPPORTED_ABIS = " + Arrays.toString(Build.SUPPORTED_ABIS));
	}

	/**
	 * Performs a shell command with root privileges.
	 * @param command command to execute
	 * @return exit code
	 */
	public static int runAsRoot(final String command) {
		Process process = null;

		try {
			process = new ProcessBuilder("su").redirectErrorStream(true).start();

			final Process runningProcess = process;

			final Thread outputReader = new Thread(() -> {
				try (
					BufferedReader reader = new BufferedReader(
						new InputStreamReader(
							runningProcess.getInputStream()
						)
					)
				) {
					String line;

					while ((line = reader.readLine()) != null) {
						Log.d("Shell", line);
					}
				} catch (final IOException e) {
					Log.d("Shell", "Shell output stream closed", e);
				}
			}, "ShellOutput");

			outputReader.setDaemon(true);
			outputReader.start();

			try (DataOutputStream os = new DataOutputStream(process.getOutputStream())) {
				os.writeBytes(command + "\n");
				os.writeBytes("exit\n");
				os.flush();
			}

			final long deadline = System.currentTimeMillis() + SHELL_TIMEOUT_MS;

			while (System.currentTimeMillis() < deadline) {
				try {
					final int exitCode = process.exitValue();
					outputReader.join(500L);
					return exitCode;
				} catch (final IllegalThreadStateException ignored) {
					Thread.sleep(50L);
				}
			}

			Log.e("Shell", "Shell command timed out: " + command);
			process.destroy();
		} catch (final InterruptedException e) {
			Thread.currentThread().interrupt();
			if (process != null) {
				process.destroy();
			}
			Log.e("Shell", "Shell command interrupted: " + command, e);
		} catch (final IOException | SecurityException e) {
			Log.e("Shell", "Failed to run shell command: " + command, e);
		}
		return -1;
	}

	public static void sleep(final int ms) {
		try {
			Thread.sleep(ms);
		} catch (final InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public static int parseInt(final String s) {
		try {
			return Integer.parseInt(s);
		} catch (final NumberFormatException e) {
			return Integer.MAX_VALUE;
		}
	}

	public static String getMHz(final int kHz) {
		return getMHz(kHz, 1);
	}

	public static String getMHz(final int kHz, final int precision) {
		return String.format(Locale.ENGLISH, "%5." + precision + "f", kHz / 1000.);
	}

	public static String getTimeStringBySeconds(final long seconds) {
		double second = Math.floor(seconds % 60);
		double minute = Math.floor(seconds / 60f % 60f);
		long hour = Math.round(Math.floor(seconds / 60f / 60f % 60f));

		return (hour > 0 ? hour + ":" : "") + String.format(Locale.ENGLISH, "%02.0f:%02.0f", minute, second);
	}

	public static void alert(final Context context, final @StringRes int title, final @StringRes int content, final @StringRes int ok) {
		new AlertDialog.Builder(context)
				.setTitle(title)
				.setMessage(content)
				.setCancelable(false)
				.setPositiveButton(ok, (dialog, which) -> dialog.cancel())
				.create()
				.show();
	}

	public static void sendAppBroadcast(final Context context, final Intent intent) {
		intent.setPackage(BuildConfig.APPLICATION_ID);
		context.sendBroadcast(intent);
	}

	public static void registerAppReceiver(final Context context, final BroadcastReceiver receiver, final IntentFilter filter) {
		ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
	}

	public interface FetchCallback {
		void onSuccess(final JSONObject result);
		default void onError(final Throwable exception) {
			exception.printStackTrace();
		}
	}

	public static boolean isInternetAvailable() {
		try {
			final InetAddress address = InetAddress.getByName("www.google.com");

			//noinspection EqualsBetweenInconvertibleTypes
			return address != null && !address.equals("");
		} catch (final UnknownHostException e) {
			// Log error
		}
		return false;
	}

	public static void fetch(final String urlString, final FetchCallback callback) {
		// Create new thread, cause requests to network not allowed in main thread (UI thread)
		new Thread(() -> {
			// Check if Internet available
			if (!isInternetAvailable()) {
				uiThread(() -> callback.onError(new Error("No Internet connection")));
				return;
			}

			try {
				final URL url = new URL(urlString);
				final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");
				connection.setReadTimeout(10000);
				connection.setConnectTimeout(15000);
				connection.setDoOutput(true);
				connection.connect();

				final BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
				final StringBuilder sb = new StringBuilder();

				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();

				final JSONObject json = new JSONObject(sb.toString());

				// Return result to main/UI thread
				uiThread(() -> callback.onSuccess(json));
			} catch (final IOException | JSONException e) {
				// Return error to main/UI thread
				uiThread(() -> callback.onError(e));
			}
		}).start();
	}

	public static void uiThread(final Runnable run) {
		new Handler(Looper.getMainLooper()).post(run);
	}

	public static String getCountryISO(final Context context) {
		try {
			final TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			final String simCountry = tm.getSimCountryIso();

			// SIM country code is available
			if (simCountry != null && simCountry.length() == 2) {
				return simCountry.toLowerCase(Locale.US);
			} else if (tm.getPhoneType() != TelephonyManager.PHONE_TYPE_CDMA) { // device is not 3G (would be unreliable)
				String networkCountry = tm.getNetworkCountryIso();
				if (networkCountry != null && networkCountry.length() == 2) { // network country code is available
					return networkCountry.toLowerCase(Locale.US);
				}
			}
		} catch (Exception ignored) {
		}

		return null;
	}

	public static void browseUrl(final Context context, @NonNull final String url) {
		final Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse(url));
		context.startActivity(intent);
	}
}
