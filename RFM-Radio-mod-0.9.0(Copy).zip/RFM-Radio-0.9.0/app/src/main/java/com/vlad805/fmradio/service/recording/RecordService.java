package com.vlad805.fmradio.service.recording;

import android.content.Context;
import android.content.Intent;
import com.vlad805.fmradio.C;
import com.vlad805.fmradio.Utils;
import com.vlad805.fmradio.service.fm.RecordError;

import java.io.*;
import java.nio.channels.FileChannel;

/**
 * Abstract recorder
 * vlad805 (c) 2021
 */
public abstract class RecordService implements IFMRecorder {
    public enum State {
        IDLE,
        RECORDING,
        FINISHING,
        DONE
    }

    /**
     * Minimal delay for update
     */
    private static final int MIN_DELAY_PING = 750;

    private final Context mContext;

    /**
     * Current frequency
     */
    private final int mKHz;

    /**
     * Recording sample rate
     */
    private final int mSampleRate;

    /**
     * State of recording
     */
    private State mState = State.IDLE;

    /**
     * Recordable file
     */
    private RecordingTarget mRecordingTarget = null;

    /**
     * Size of file in bytes
     */
    protected int mRecordLength = 0;

    /**
     * Writable stream
     */
    protected BufferedOutputStream mBufferOutStream = null;
    private FileOutputStream mFileOutStream = null;

    /**
     * Timestamp of start recording
     */
    private long mStarted;

    /**
     * Last broadcasting
     */
    private long mLast;

    /** Number of interleaved PCM samples accepted by the encoder. */
    private long mRecordedPcmSamples;

    /** Duration reported before the pre-roll snapshot reaches the encoder. */
    private int mInitialDurationMillis;

    /**
     * Constructor
     * @param context Context
     * @param kHz Current frequency in kHz
     */
    public RecordService(
            final Context context,
            final int kHz,
            final int sampleRate
    ) {
        mContext = context;
        mKHz = kHz;
        mSampleRate = sampleRate;
    }

    /**
     * Calls when user click "Start recording"
     * @param initialDurationMillis Duration of included pre-roll PCM in milliseconds
     * @throws RecordError If something going wrong
     */
    @Override
    public final synchronized void startRecord(final int initialDurationMillis) throws RecordError {
        mStarted = System.currentTimeMillis() - Math.max(0, initialDurationMillis);
        mInitialDurationMillis = Math.max(0, initialDurationMillis);
        mRecordedPcmSamples = 0;
        createFile();
        mState = State.RECORDING;
        updateState(C.Event.RECORD_STARTED);
    }

    @Override
    public final synchronized void record(final short[] data, final int length) {
        if (mState == State.RECORDING) {
            try {
                byte[] bufferEncoded = new byte[(int) (7200 + data.length * 2 * 1.75)];
                int bytesEncoded = onReceivedData(data, length, bufferEncoded);
                mBufferOutStream.write(bufferEncoded, 0, bytesEncoded);
                mRecordLength += bytesEncoded;
                mRecordedPcmSamples += length;
            } catch (IOException e) {
                e.printStackTrace();
                mState = State.IDLE;
            }

            final long now = System.currentTimeMillis();
            if (now - mLast > MIN_DELAY_PING) {
                mLast = now;
                updateState(C.Event.RECORD_TIME_UPDATE);
            }
        }
    }

    /**
     * Called on user click "Stop record"
     */
    @Override
    public synchronized void stopRecord() {
        if (mState == State.FINISHING || mState == State.DONE) {
            return;
        }

        if (mRecordingTarget == null) {
            return;
        }

        // Reject further PCM data before flushing and closing the encoder.
        mState = State.FINISHING;

        onFinishRecording();

        try {
            if (mBufferOutStream != null) {
                mBufferOutStream.close();
                mBufferOutStream = null;
            }
        } catch (final IOException e) {
            e.printStackTrace();
        }

        try {
            if (mFileOutStream != null) {
                mFileOutStream.close();
                mFileOutStream = null;
            }
        } catch (final IOException e) {
            e.printStackTrace();
        }

        if (mRecordingTarget != null) {
            final RecordingTarget target = mRecordingTarget;
            try {
                target.commit();
                updateCompletedState(target);
            } catch (IOException e) {
                e.printStackTrace();
                target.abort();
                updateState(C.Event.RECORD_FAILED);
            }
            target.closeQuietly();
            mRecordingTarget = null;
        }
        mState = State.DONE;
    }

    /**
     * Send event. Also send size of file, duration and path
     * @param event Key of event
     */
    private void updateState(final String event) {
        Utils.sendAppBroadcast(mContext, new Intent(event)
                .putExtra(C.Key.SIZE, mRecordLength)
                .putExtra(C.Key.DURATION, getDurationSeconds())
                .putExtra(C.Key.PATH, getDisplayPath())
        );
    }

    private void updateCompletedState(final RecordingTarget target) {
        final Intent intent = new Intent(C.Event.RECORD_ENDED)
                .putExtra(C.Key.SIZE, mRecordLength)
                .putExtra(C.Key.DURATION, getDurationSeconds())
                .putExtra(C.Key.PATH, target.getDisplayPath())
                .putExtra(C.Key.DISPLAY_NAME, target.getDisplayName());

        if (target.getPublishedUri() != null) {
            intent.putExtra(C.Key.RECORDING_URI, target.getPublishedUri().toString());
        } else {
            intent.putExtra(C.Key.RECORDING_FILE_PATH, target.getPublishedFilePath());
        }

        Utils.sendAppBroadcast(mContext, intent);
    }

    /**
     * Returns state
     * @return State
     */
    public synchronized State getState() {
        return mState;
    }

    /**
     * Returns duration represented by the accepted PCM samples.
     * Uses the initial pre-roll duration while its queued samples are still being encoded.
     *
     * @return Duration in seconds
     */
    public synchronized int getDurationSeconds() {
        final long recordedMillis = (mRecordedPcmSamples * 1000L) / (mSampleRate * 2L);
        return (int) (Math.max(mInitialDurationMillis, recordedMillis) / 1000L);
    }

    /**
     * Create file and initialize streams
     */
    private void createFile() throws RecordError {
        RecordingTarget target = null;

        try {
            target = RecordingStorage.create(mContext, mKHz, getExtension(), getMimeType());
            mFileOutStream = target.openOutputStream();
            mBufferOutStream = new BufferedOutputStream(mFileOutStream, 131072);
            mRecordingTarget = target;

            onFileCreated();
        } catch (RecordError e) {
            if (target != null) {
                target.abort();
            }
            mRecordingTarget = null;
            throw e;
        } catch (IllegalStateException e) {
            if (target != null) {
                target.abort();
            }
            mRecordingTarget = null;
            throw new RecordError(e.getMessage());
        } catch (IOException e) {
            if (target != null) {
                target.abort();
            }
            mRecordingTarget = null;
            throw new RecordError("Cannot create recording file");
        }
    }

    protected final int getSampleRate() {
        return mSampleRate;
    }

    protected final int getFrequencyKhz() {
        return mKHz;
    }

    protected final long getStartedAtMillis() {
        return mStarted;
    }

    protected final FileChannel getRecordingChannel() {
        return mFileOutStream != null ? mFileOutStream.getChannel() : null;
    }

    public final String getDisplayPath() {
        return mRecordingTarget != null ? mRecordingTarget.getDisplayPath() : "";
    }

    public final String getDisplayName() {
        return mRecordingTarget != null ? mRecordingTarget.getDisplayName() : "";
    }

    public final int getCurrentSizeBytes() {
        return mRecordLength;
    }

    /**
     * Return file extension
     * @return Extension without ".": for example "mp3" or "wav".
     */
    protected abstract String getExtension();

    protected abstract String getMimeType();

    /**
     * Calls when file created and opened streams for write.
     */
    protected abstract void onFileCreated() throws IOException;

    /**
     * Calls when AudioRecord receive new packet of data
     * @param data New data
     * @param length Length of data
     * @param encoded Pointer to byte array of encoded data (output)
     * @return Length of payload encoded array
     * @throws IOException If happens error
     */
    protected abstract int onReceivedData(final short[] data, final int length, final byte[] encoded) throws IOException;

    /**
     * Calls when recording is finished.
     */
    protected abstract void onFinishRecording();
}
